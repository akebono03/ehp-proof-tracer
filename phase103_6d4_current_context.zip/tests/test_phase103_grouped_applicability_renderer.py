from repository_generator_applicability_presentation import (
  build_repository_generator_applicability_presentation,
)
from repository_generator_applicability_renderer import (
  render_repository_generator_applicability_markdown,
)
from test_phase103_grouped_applicability_presentation import (
  build_grouped_fixture,
)


def test_phase103_6c1_renderer_groups_repeated_source_metadata():
  data = build_grouped_fixture()

  markdown = (
    render_repository_generator_applicability_markdown(
      data[
        "result"
      ]
    )
  )

  assert (
    "Applicability candidates: 4"
    in markdown
  )

  assert (
    "Source statements with candidates: 2"
    in markdown
  )

  assert (
    "Rule groups: 3"
    in markdown
  )

  assert (
    "## Candidates"
    in markdown
  )

  assert (
    "### Other statements"
    in markdown
  )

  assert (
    markdown.count(
      "Root: phase103.grouped.root"
    )
    == 2
  )


def test_phase103_6c1_renderer_groups_same_rule_but_keeps_premise_matches():
  data = build_grouped_fixture()

  markdown = (
    render_repository_generator_applicability_markdown(
      data[
        "result"
      ]
    )
  )

  assert (
    markdown.count(
      "Rule: first grouped rule"
    )
    == 2
  )

  first_source_block = (
    markdown.split(
      "#### Source statement: GeneratorSymbol"
    )[
      1
    ]
  )

  assert (
    "Premise index: 0; Bindings: 0"
    in first_source_block
  )

  assert (
    "Premise index: 1; Bindings: 0"
    in first_source_block
  )

def test_phase103_6c1_renderer_keeps_existing_public_contract_strings():
  data = build_grouped_fixture()

  markdown = (
    render_repository_generator_applicability_markdown(
      data[
        "result"
      ]
    )
  )

  assert (
    "# Applicable theorem / lemma candidates for $\\nu'$"
    in markdown
  )

  assert (
    "Proof-scope occurrences:"
    in markdown
  )

  assert (
    "Applicability candidates:"
    in markdown
  )

  assert (
    "Premise index: 0"
    in markdown
  )

  assert (
    "Bindings: 0"
    in markdown
  )

  assert (
    "Fixed-point safe: yes"
    in markdown
  )

  assert (
    "Fixed-point safe: no"
    in markdown
  )

def test_phase103_6c1_builder_and_renderer_do_not_change_raw_result():
  data = build_grouped_fixture()

  before = (
    data[
      "result"
    ].candidates
  )

  presentation = (
    build_repository_generator_applicability_presentation(
      data[
        "result"
      ]
    )
  )

  render_repository_generator_applicability_markdown(
    data[
      "result"
    ]
  )

  after = (
    data[
      "result"
    ].candidates
  )

  assert (
    after
    == before
  )

  assert all(
    actual is expected
    for actual, expected in zip(
      after,
      before,
    )
  )

  assert (
    len(
      presentation.source_groups
    )
    == 2
  )
