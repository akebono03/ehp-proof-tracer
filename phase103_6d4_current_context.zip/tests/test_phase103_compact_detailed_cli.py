from types import SimpleNamespace

import pytest

import main as cli_main


def test_phase103_6c5_explore_applicable_default_uses_legacy_compact_alias(
  monkeypatch,
  capsys,
):
  fake_result = SimpleNamespace()

  monkeypatch.setattr(
    cli_main,
    (
      "explore_standard_repository_"
      "generator_applicability_input"
    ),
    lambda generator_input: fake_result,
  )

  monkeypatch.setattr(
    cli_main,
    (
      "render_repository_generator_"
      "applicability_markdown"
    ),
    lambda result: "COMPACT REPORT\n",
  )

  monkeypatch.setattr(
    cli_main,
    (
      "render_repository_generator_"
      "applicability_detailed_markdown"
    ),
    lambda result: "DETAILED REPORT\n",
  )

  exit_code = cli_main.main(
    [
      "explore-applicable",
      "nu_prime",
    ]
  )

  captured = capsys.readouterr()

  assert exit_code == 0
  assert captured.out == "COMPACT REPORT\n"
  assert captured.err == ""


def test_phase103_6c5_explore_applicable_detailed_flag_uses_detailed_renderer(
  monkeypatch,
  capsys,
):
  fake_result = SimpleNamespace()

  monkeypatch.setattr(
    cli_main,
    (
      "explore_standard_repository_"
      "generator_applicability_input"
    ),
    lambda generator_input: fake_result,
  )

  monkeypatch.setattr(
    cli_main,
    (
      "render_repository_generator_"
      "applicability_markdown"
    ),
    lambda result: "COMPACT REPORT\n",
  )

  monkeypatch.setattr(
    cli_main,
    (
      "render_repository_generator_"
      "applicability_detailed_markdown"
    ),
    lambda result: "DETAILED REPORT\n",
  )

  exit_code = cli_main.main(
    [
      "explore-applicable",
      "nu_prime",
      "--detailed",
    ]
  )

  captured = capsys.readouterr()

  assert exit_code == 0
  assert captured.out == "DETAILED REPORT\n"
  assert captured.err == ""


def test_phase103_6c5_explore_applicable_help_documents_detailed_flag(
  capsys,
):
  with pytest.raises(
    SystemExit,
  ) as exc_info:
    cli_main.main(
      [
        "explore-applicable",
        "--help",
      ]
    )

  captured = capsys.readouterr()

  assert exc_info.value.code == 0

  assert (
    "main.py explore-applicable"
    in captured.out
  )

  assert "--detailed" in captured.out
  assert "generator" in captured.out
  assert captured.err == ""
