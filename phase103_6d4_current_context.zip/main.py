import argparse
from collections.abc import Sequence
import sys

from repository_element_facade import (
  explore_standard_repository_generator_input,
)
from repository_generator_applicability_facade import (
  explore_standard_repository_generator_applicability_input,
)
from repository_generator_applicability_renderer import (
  render_repository_generator_applicability_compact_markdown,
  render_repository_generator_applicability_detailed_markdown,
)

render_repository_generator_applicability_markdown = (
  render_repository_generator_applicability_compact_markdown
)
from repository_proof_scope_facade import (
  explore_standard_repository_generator_proof_scope_input,
)
from repository_proof_scope_renderer import (
  render_repository_proof_scope_exploration_markdown,
)
from toda_calculation_facade import (
  build_standard_toda_report,
)
from toda_calculation_result import (
  TodaCalculationStatus,
)


def _parse_positive_int(
  value: str,
) -> int:
  parsed = int(
    value
  )

  if parsed <= 0:
    raise argparse.ArgumentTypeError(
      "must be positive"
    )

  return parsed


def _parse_nonnegative_int(
  value: str,
) -> int:
  parsed = int(
    value
  )

  if parsed < 0:
    raise argparse.ArgumentTypeError(
      "must be nonnegative"
    )

  return parsed


def build_argument_parser(
) -> argparse.ArgumentParser:
  parser = argparse.ArgumentParser(
    description=(
      "Build a Toda homotopy-group proof report "
      "from the standard production repository."
    ),
  )

  parser.add_argument(
    "n",
    type=_parse_positive_int,
    help="sphere dimension n",
  )

  parser.add_argument(
    "k",
    type=_parse_nonnegative_int,
    help="stem k for pi_{n+k}(S^n)",
  )

  return parser


def build_explore_argument_parser(
) -> argparse.ArgumentParser:
  parser = argparse.ArgumentParser(
    prog="main.py explore",
    description=(
      "Explore occurrences of one generator "
      "in the standard production repository."
    ),
  )

  parser.add_argument(
    "generator",
    help=(
      "generator input such as "
      "nu_prime, nu_5, or eta_2"
    ),
  )

  return parser


def build_explore_proof_argument_parser(
) -> argparse.ArgumentParser:
  parser = argparse.ArgumentParser(
    prog="main.py explore-proof",
    description=(
      "Explore one generator across the recursive "
      "proof ancestry of the standard production "
      "repository."
    ),
  )

  parser.add_argument(
    "generator",
    help=(
      "generator input such as "
      "nu_prime, nu_5, or eta_2"
    ),
  )

  return parser

def build_explore_applicable_argument_parser(
) -> argparse.ArgumentParser:
  parser = argparse.ArgumentParser(
    prog="main.py explore-applicable",
    description=(
      "Find theorem / lemma applicability "
      "candidates for one generator across the "
      "recursive proof ancestry of the standard "
      "production repository."
    ),
  )

  parser.add_argument(
    "generator",
    help=(
      "generator input such as "
      "nu_prime, nu_5, or eta_2"
    ),
  )

  parser.add_argument(
    "--detailed",
    action="store_true",
    help=(
      "show full catalog-entry, premise-index, "
      "binding, and fixed-point provenance"
    ),
  )

  return parser

def _run_explore_command(
  generator_input: str,
) -> int:
  try:
    report = (
      explore_standard_repository_generator_input(
        generator_input
      )
    )
  except (
    TypeError,
    ValueError,
  ) as error:
    parser = (
      build_explore_argument_parser()
    )
    parser.error(
      str(
        error
      )
    )

  print(
    report.markdown,
    end="",
  )

  return 0


def _run_explore_proof_command(
  generator_input: str,
) -> int:
  try:
    result = (
      explore_standard_repository_generator_proof_scope_input(
        generator_input
      )
    )
  except (
    TypeError,
    ValueError,
  ) as error:
    parser = (
      build_explore_proof_argument_parser()
    )
    parser.error(
      str(
        error
      )
    )

  markdown = (
    render_repository_proof_scope_exploration_markdown(
      result
    )
  )

  print(
    markdown,
    end="",
  )

  return 0

def _run_explore_applicable_command(
  generator_input: str,
  detailed: bool = False,
) -> int:
  try:
    result = (
      explore_standard_repository_generator_applicability_input(
        generator_input
      )
    )
  except (
    TypeError,
    ValueError,
  ) as error:
    parser = (
      build_explore_applicable_argument_parser()
    )
    parser.error(
      str(
        error
      )
    )

  renderer = (
    render_repository_generator_applicability_detailed_markdown
    if detailed
    else render_repository_generator_applicability_markdown
  )

  markdown = renderer(
    result
  )

  print(
    markdown,
    end="",
  )

  return 0

def main(
  argv: Sequence[str] | None = None,
) -> int:
  raw_argv = (
    list(
      argv
    )
    if argv is not None
    else sys.argv[
      1:
    ]
  )

  if (
    raw_argv
    and raw_argv[
      0
    ] == "explore"
  ):
    parser = (
      build_explore_argument_parser()
    )

    args = parser.parse_args(
      raw_argv[
        1:
      ]
    )

    return _run_explore_command(
      args.generator
    )

  if (
    raw_argv
    and raw_argv[
      0
    ] == "explore-proof"
  ):
    parser = (
      build_explore_proof_argument_parser()
    )

    args = parser.parse_args(
      raw_argv[
        1:
      ]
    )

    return _run_explore_proof_command(
      args.generator
    )

  if (
    raw_argv
    and raw_argv[
      0
    ] == "explore-applicable"
  ):
    parser = (
      build_explore_applicable_argument_parser()
    )

    args = parser.parse_args(
      raw_argv[
        1:
      ]
    )

    return _run_explore_applicable_command(
      args.generator,
      detailed=args.detailed,
    )

  parser = build_argument_parser()

  args = parser.parse_args(
    raw_argv
  )

  result = (
    build_standard_toda_report(
      n=args.n,
      k=args.k,
    )
  )

  if (
    result.status
    is TodaCalculationStatus.NOT_FOUND
  ):
    print(
      "No proof report found for "
      f"pi_{{{args.n + args.k}}}^{{{args.n}}}."
    )
    return 1

  print(
    "\n\n---\n\n".join(
      result.reports
    )
  )

  return 0


if __name__ == "__main__":
  raise SystemExit(
    main()
  )
