from toda_calculation_facade import (
  build_standard_toda_report,
)
from toda_group_proof_narrative_contribution_renderer import (
  _toda_group_proof_narrative_reference_frontier_step_ids,
  _toda_group_proof_narrative_root_fixed_statement_internal_step_ids,
)
from toda_group_proof_narrative_references import (
  build_toda_group_proof_narrative_reference_entries,
  exclude_toda_group_proof_narrative_root_reference,
  filter_toda_group_proof_narrative_reference_entries_by_fixed_statement_boundary,
)
from toda_group_proof_narrative_renderer import (
  render_toda_group_proof_narrative_markdown,
)
from toda_group_proof_narrative_semantics import (
  build_toda_group_proof_narrative_semantic_closure_presentation,
)
from toda_group_proof_presentation import (
  build_toda_group_proof_presentation,
)
from toda_group_result_proof_replay import (
  build_toda_group_result_proof_replay,
)


def _phase161_r4_r4_presentations(
  n: int,
  k: int,
  depth: int,
):
  report = build_standard_toda_report(
    n=n,
    k=k,
  )
  group_result = (
    report
    .candidates[0]
    .source_candidate
    .group_result
  )
  replay = build_toda_group_result_proof_replay(
    group_result,
    max_depth=depth,
  )
  raw = build_toda_group_proof_presentation(
    replay
  )
  presentation = (
    build_toda_group_proof_narrative_semantic_closure_presentation(
      raw
    )
  )

  return (
    raw,
    presentation,
  )


def _phase161_r4_r4_pi4_2_entries(
  presentation,
):
  entries = (
    build_toda_group_proof_narrative_reference_entries(
      presentation
    )
  )
  entries = (
    filter_toda_group_proof_narrative_reference_entries_by_fixed_statement_boundary(
      entries,
      presentation.root_step,
    )
  )
  statement_lines = {
    entry.number: ()
    for entry in entries
  }
  entries, _ = (
    exclude_toda_group_proof_narrative_root_reference(
      entries,
      statement_lines,
      presentation.root_step,
    )
  )

  return entries


def _phase161_r4_r4_phase156_frontier_entries(
  presentation,
):
  entries = (
    build_toda_group_proof_narrative_reference_entries(
      presentation
    )
  )
  statement_lines = {
    entry.number: ()
    for entry in entries
  }
  entries, _ = (
    exclude_toda_group_proof_narrative_root_reference(
      entries,
      statement_lines,
      presentation.root_step,
    )
  )

  return entries


def test_phase161_r4_r4_pi4_2_root_fixed_internality_hides_prop44_only():
  (
    raw,
    presentation,
  ) = _phase161_r4_r4_presentations(
    2,
    2,
    2,
  )
  entries = (
    _phase161_r4_r4_pi4_2_entries(
      presentation
    )
  )

  internal_step_ids = (
    _toda_group_proof_narrative_root_fixed_statement_internal_step_ids(
      presentation
    )
  )

  prop44 = next(
    node.proof_step
    for node in presentation.nodes
    if (
      node.proof_step.inference_rule
      is not None
      and node.proof_step.inference_rule.name
      == "Toda Proposition 4.4 eta_2 n=2 specialization"
    )
  )
  restriction = next(
    node.proof_step
    for node in presentation.nodes
    if (
      node.proof_step.inference_rule
      is not None
      and node.proof_step.inference_rule.name
      == "Toda Proposition 4.4 eta_2 second-summand restriction"
    )
  )

  assert id(
    prop44
  ) in internal_step_ids
  assert id(
    restriction
  ) in internal_step_ids

  rendered = render_toda_group_proof_narrative_markdown(
    raw
  )
  reference, body = rendered.split(
    "---",
    1,
  )

  assert "**[R1] (5.2).**" in reference
  assert "Proposition 4.4" not in reference
  assert (
    r"\pi_{i - 1}^{1} \oplus "
    r"\pi_{i}^{3} \to "
    r"\pi_{i}^{2}"
    not in body
  )
  assert "分解写像の第二成分" not in body
  assert "[R1]" in body
  assert "$i=4$" in body
  assert (
    r"\pi_{4}^{3} \to \pi_{4}^{2}"
    in body
  )


def test_phase161_r4_r4_restores_phase156_global_frontier_contract():
  (
    _,
    presentation,
  ) = _phase161_r4_r4_presentations(
    3,
    3,
    2,
  )
  entries = (
    _phase161_r4_r4_phase156_frontier_entries(
      presentation
    )
  )

  frontier_step_ids = (
    _toda_group_proof_narrative_reference_frontier_step_ids(
      presentation,
      entries,
    )
  )
  frontier_locators = {
    entry.reference.locator
    for entry in entries
    if any(
      id(
        proof_step
      )
      in frontier_step_ids
      for proof_step in entry.proof_steps
    )
  }

  assert "(5.3)" in frontier_locators
  assert "Proposition 5.3" in frontier_locators
  assert "Lemma 5.4" in frontier_locators
  assert "(5.2)" in frontier_locators
  assert "Proposition 5.1" not in frontier_locators

  assert (
    _toda_group_proof_narrative_root_fixed_statement_internal_step_ids(
      presentation
    )
    == frozenset()
  )
