証明対象
\pi_{5}^{3}
使用する結果
参照情報を持つ ProofStep はありません。

証明
探索状態：部分証明・未完成
確認済み ProofStep（与件を含む）
- 与件: observed
未解決 Goal
- unknown
未解決 Goal は証明済みの結論ではありません。