## 証明対象

$\pi_{7}^{5}$

## 使用する結果

参照情報を持つ ProofStep はありません。

---

## 証明

**探索状態：証明未完成**


## 未解決 Goal

- CyclicStructureStatement（数式表示未対応）
- $\pi_{7}^{5} = \mathbb{Z}/2\{\eta_{5}^{2}\}$
- $\mathbb{Z}/2\{\eta_{5}^{2}\} = \pi_{7}^{5}$

## 探索診断

- expected one registered derivation for Relation(lhs=TodaPrimaryGroup(group_dimension=7, sphere_dimension=5), rhs=FiniteCyclicGroup(order=2, generator=Composition(left=HomotopyElement(name='η₅', dimension=5, source=6, target=5, generator=GeneratorSymbol(family='η', index=5, decoration=None)), right=HomotopyElement(name='η₆', dimension=6, source=7, target=6, generator=GeneratorSymbol(family='η', index=6, decoration=None)))), relation_type=<RelationType.EQUALITY: 'equality'>, source=None, note=None), found 0

未解決 Goal は証明済みの結論ではありません。
