# Phase 168 — Active pytest 収集範囲診断

- 実行対象: `tests/ (no automatic ignores or exclusion)`
- 判定: `ACTIVE_SUITE_INCOMPLETE`
- pytest exit code: `1`
- 欠落した test helper の静的参照数: `2`

収集エラーや失敗は無視していない。PASS と記録するのは pytest exit code 0 で、
既知の欠落した test helper がない場合に限る。

## 欠落するテスト依存

- `tests/test_phase144_6_pi6_generic_production_route.py` -> `tests.test_phase143_19_method_evidence`
  - 退避先: `archive/phases/phase143_19/tests/test_phase143_19_method_evidence.py`
- `tests/test_phase144_6_public_route_cutover.py` -> `tests.test_phase143_19_method_evidence`
  - 退避先: `archive/phases/phase143_19/tests/test_phase143_19_method_evidence.py`

## pytest の主な診断行

- 取得なし

## 完了判定

静的検査は動的 import 全体を保証しない。
pytest が失敗した場合は Phase 168 の全体テスト合格と判定しない。
