使用する結果

**[R1] Chapter V, i).**

$n\ge 2$ に対し, $\eta_n=E^{n-2}\eta_2$ と定義する.

**[R2] (5.1).**

$\pi_{n}^{n} = \mathbb{Z}\{\iota_{n}\}\quad(n\ge 1)$.

$\pi_i^n=0\quad(i<n)$.

**[R3] Proposition 5.1.**

$\Delta\left(\iota_{5}\right) = \pm 2\eta_{2}$.

$\pi_{3}^{2} = \mathbb{Z}\{\eta_{2}\}$.

**[R4] Proposition 4.2 (4.4).**

$\pi_i^n\xrightarrow{E}\pi_{i+1}^{n+1}\xrightarrow{H}\pi_{i+1}^{2n+1}\xrightarrow{\Delta}\pi_{i-1}^{n}\xrightarrow{E}\pi_i^{n+1}$ は完全.

証明

群構造を決定するために, [R4]を用いて次の完全列を考える.

$\pi_{5}^{5} \xrightarrow{\Delta} \pi_{3}^{2} \xrightarrow{E} \pi_{4}^{3} \xrightarrow{H} \pi_{4}^{5}$.

[R1]より, $E(\eta_{2})=\eta_{3}$.

[R2]より, $\pi_{5}^{5} = \mathbb{Z}\{\iota_{5}\}$.

[R3]より, $\Delta\left(\iota_{5}\right) = \pm 2\eta_{2}$.

これより, $\operatorname{Im}\Delta=\mathbb{Z}\{2\eta_{2}\}$.

完全性より, $\operatorname{Im}\Delta=\ker E$ .

完全性より, $\ker E=\mathbb{Z}\{2\eta_{2}\}$.

[R2]より, $\pi_{4}^{5} = 0$.

完全性より, $E: \pi_{3}^{2}\to \pi_{4}^{3}$ は全射.

[R3]より, $\pi_{3}^{2} = \mathbb{Z}\{\eta_{2}\}$.

全射性と核の決定から, 準同型定理より $\pi_{4}^{3}\cong \pi_{3}^{2}/\mathbb{Z}\{2\eta_{2}\}$.

以上より, $\pi_{4}^{3} = \mathbb{Z}/2\{\eta_{3}\}$.

□
