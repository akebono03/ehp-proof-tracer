# EHP Proof Tracer 設計

この文書は EHP Proof Tracer の**現在有効なアーキテクチャ、意味論、不変条件、設計境界**を記録する。

過去の実装経緯は `docs/development_log.md`、証明記録は `docs/proof_records.md`、今後の計画は `docs/roadmap.md`、コード探索は `docs/code_reference.md` を参照する。

---

# 1. 基本設計原則

```text
実際の数学的・証明探索上の必要
↓
不足している最小表現
↓
必要な領域固有規則 / オーケストレーション
↓
既存の汎用基盤
```

次を混同しない。

```text
表現 != 型付け != 定理知識
構造的等値 != 数学的等値
探索計画 != 証明結果
表示層 != 証明事実
proof-scope 走査 != 定理探索
proof-scope relevance != executable relevance
applicability relevance != executable relevance
aggregate statement 内の別 branch occurrence != executable source relevance
既知関係の発見 != 写像評価
適用可能候補 != 証明成功
候補番号 != 数学的優先度
operation query != general evaluator
limited theorem-specific handoff != general query inference
theorem-specific membership handoff != general membership evaluator
group-generator containment != operation result
target group zero specialization != general zero-target evaluator
stable-family specialization != unrestricted symbolic substitution
concrete proof recovery != new theorem root
negative stem acceptance != negative homotopy group definition
pi_0 boundary information != ordinary group result
Web UI != 新しい数学エンジン
TeX rendering != 数学的 normalization
proof depth control != 新しい proof search
semantic renderer != 新しい数学的事実
rule-name fallback 除去 != proof semantics 変更
safe fallback != 推測した数学的説明
candidate selection != theorem ranking
Web execution != second execution engine
executable relevance filtering != theorem ranking
group-result proof replay != generator lookup
group-result proof replay != new proof search
proof narrative != new proof
Outline != proof search
Narrative deduplication != proof graph deletion
Narrative label != proof fact
human-readable label != semantic rewrite
Web presentation adapter != proof semantics
```

---

# 2. Toda group query の主要経路

```text
ProofRepository
→ TodaGroupQuery
→ foundational specialization
→ direct known-group lookup
→ concrete proof-ancestry recovery
→ stable/theorem-specific specialization
→ TodaGroupResult
→ proof / EHP provenance
→ structured presentation
→ report
```

Phase 130 以降、`TodaGroupQuery` は `k >= 0` に限定されない。

```text
n > 0
k は任意の int
```

ただし `n+k` の値に応じて意味論を分ける。

---

# 3. query domain semantics

\(m=n+k\) とする。

## \(m>0\)

通常の project group query の対象。

`k<0` かつ

$$
1\le m<n
$$

なら sphere connectivity により

$$
\pi_m(S^n)=0
$$

として扱う。

Phase 130 ではこの connectivity zero を repository-backed `TodaGroupResult` として具体化するため、Phase 131 以降の group-result proof replay 対象になる。

## \(m=0\)

$$
\pi_0(S^n)
$$

は通常の group result に正規化しない。

\(n>0\) の球面は path-connected なので、1つの path component を持つという boundary information を返す。

したがって group-result proof replay の対象外である。

## \(m<0\)

classical unstable homotopy-group domain 外として扱う。

負次数を zero group と推測しない。

---

# 4. foundational group specialization

Phase 130 で foundational specialization を group-query orchestration の先頭へ追加した。

## diagonal

$$
\pi_n^n\cong\mathbb Z\{\iota_n\}.
$$

これは `k=0` の query に対応する。

## circle higher groups

既存 Phase 56 の symbolic zero

$$
\pi_{i-1}^1=0
$$

を concrete query に specialize する。

したがって

$$
n=1,\quad k\ge1
$$

では

$$
\pi_{1+k}^1=0.
$$

新しい独立 theorem root は追加しない。

## connectivity zero

$$
1\le n+k<n
$$

では foundational sphere connectivity として zero result を返す。

この結果は `ProofRepositoryEntry` と `ProofStep` を持つ。

---

# 5. stem 1–3 specialization

Phase 130 では既存 symbolic theorem を standard query から具体化できるようにした。

## stem 1

$$
\pi_{n+1}^n=\mathbb Z/2\{\eta_n\}.
$$

## stem 2

$$
\pi_{n+2}^n=\mathbb Z/2\{\eta_n\eta_{n+1}\}.
$$

## stem 3

$$
\pi_{n+3}^n=\mathbb Z/8\{\nu_n\}.
$$

低次元 concrete boundary が既存 proof にある場合は concrete proof を優先する。

---

# 6. stem 4–6 specialization

## stem 4

$$
\pi_{n+4}^n=0,
\qquad n\ge6.
$$

## stem 5

低次元 concrete branch を proof ancestry から回収し、

$$
\pi_{n+5}^n=0,
\qquad n\ge7
$$

を symbolic branch から specialize する。

## stem 6

$$
\pi_{n+6}^n=\mathbb Z/2\{\nu_n^2\}.
$$

既存 concrete \(n=5,6,7,8\) を維持し、symbolic specialization はその境界より上で使う。

---

# 7. stem 7 / sigma family

Toda Proposition 5.15 の既存証明には

$$
\pi_{16}^9=\mathbb Z/16\{\sigma_9\}
$$

という concrete proof が存在する。

また symbolic higher branch として

$$
\pi_{n+7}^n=\mathbb Z/16\{\sigma_n\},
\qquad n\ge9
$$

が存在する。

現行設計は次のように分ける。

```text
n = 8
→ Prop.5.15 aggregate の concrete branch

n = 9
→ existing concrete pi16_9 ProofStep を proof scope から回収

n >= 10
→ theorem-specific indexed sigma specialization
```

`n=9` を generic specialization の境界へ無理に混ぜない。

---

# 8. standard repository 非破壊

Phase 130 の specialization / recovery は standard repository root を追加しない。

期待する root:

```text
standard.toda.prop56
standard.toda.prop58
standard.toda.prop511
standard.toda.prop515
```

query 実行の前後で repository entry 集合を維持する。

---

# 9. concrete proof recovery

group query で aggregate の top-level branch に存在しない concrete result が proof ancestry に存在する場合、限定的に proof scope から回収する。

Phase 130 の代表例:

$$
\pi_{16}^9=\mathbb Z/16\{\sigma_9\}.
$$

回収条件は theorem-specific かつ target-specific に狭くする。

```text
proof-scope recovery
!= arbitrary recursive theorem mining
!= theorem ranking
!= automatic proof synthesis
```

---

# 10. operation query

operation query は lookup-first である。

```text
query string
→ minimal parser
→ direct repository / proof-scope lookup
→ direct hit はそのまま返す
→ direct miss のうち許可された exact handoff のみ具体化
→ structured presentation
→ CLI / Web
```

現在許可される exact handoff:

```text
E(nu_5)
E(sigma_11)
E(nu_5 o eta_8)
E(nu_prime)
```

対応結果:

$$
E(\nu_5)=\nu_6,
\qquad
E(\sigma_{11})=\sigma_{12},
$$

$$
E(\nu_5\eta_8)=0,
\qquad
E\nu' \in \pi_7^4.
$$

---

# 11. provenance

証明事実の中心は

```text
ProofStep.conclusion
ProofStep.premises
ProofStep.inference_rule
```

である。

`ProofRepositoryEntry.key / phase / theorem` は provenance metadata。

`TodaGroupResult` はさらに

```text
source_entry
proof_step
```

を保持し、

```text
group_result.proof_step is group_result.source_entry.step
```

を不変条件とする。

```text
theorem-specific operation handoff != independent theorem root
theorem-specific membership step != general inference rule
GROUP_MEMBERSHIP match kind != membership evaluator
```

---

# 12. group-result proof replay

Phase 131 では generator ではなく群結果そのものから proof replay する経路を追加した。

```text
TodaGroupResult
→ proof_step
→ extract_toda_recursive_proof_provenance()
→ depth 制限
→ TodaGroupResultProofReplayResult
```

重要な境界:

```text
group-result replay
!= generator-first replay
!= repository re-search
!= theorem mining
!= new proof search
```

`TodaGroupResult.source_entry` と `TodaGroupResult.proof_step` の identity を維持する。

replay step は既存 recursive provenance の

```text
shortest_depth
role
ProofStep identity
```

を保持する。

これにより generator を持たない zero group でも replay できる。

例:

$$
\pi_9^2=0.
$$

また Phase 130 の foundational connectivity zero:

$$
\pi_{10}^{11}=0
$$

も repository-backed result のため replay できる。

一方、

```text
pi_0 boundary information
negative-dimensional out-of-domain information
```

は ordinary `TodaGroupResult` ではないため replay 対象外。

---

# 13. Phase 132 group proof presentation core

Phase 132 では replay 結果を Trace / Outline / Narrative へ共通接続するため、

```text
TodaGroupProofPresentation
```

を追加した。

構造:

```text
TodaGroupResultProofReplayResult
→ selected replay nodes
→ existing recursive provenance edges を selected nodes へ filter
→ TodaGroupProofPresentation
```

重要な不変条件:

```text
presentation.nodes is replay.steps
presentation.root_step is replay.root_step
presentation.source_entry is replay.source_entry
presentation.max_depth == replay.max_depth
```

presentation は新しい traversal semantics を定義しない。

```text
TodaGroupProofPresentation
!= new proof search
!= second depth semantics
!= inferred parent relation
```

proof edge は `ProofStep.premises` 由来の既存 recursive provenance を使用する。

flat replay の `depth` や表示順から parent-child relation を推測してはならない。

---

# 14. Trace / Outline / Narrative

## Trace

Phase 131 の既存 replay 表示。

```text
Depth
statement
Role
Rule
Provenance
```

監査用 ground truth とする。

## Outline

Outline は同じ presentation graph を階層的に表示する。

```text
Conclusion
→ Premise 1
→ Premise 2
→ nested premise
```

同じ親の premise は `premise_index` 順に表示する。

```text
premise_index order
!= global causal order
```

shared dependency が別 branch から参照される場合、graph 構造を保持するため Outline では必要に応じて複数箇所に現れてよい。

## Narrative

Narrative は固定テンプレートで同じ graph を文章化する。

```text
source theorem
premise fact
nested consequence
root conclusion
```

新しい数学的説明を自由生成しない。

Phase 133 以降の statement 表示優先順は次のとおり。

```text
既存 LaTeX renderer
→ 明示的 human-readable Narrative label
→ inference rule name
→ statement type name
```

明示的 Narrative label は、既存 statement type の表示名を人間向けにするだけである。

```text
human-readable Narrative label
!= theorem inference
!= statement semantic rewrite
!= new theorem fact
```

代表例:

```text
Toda56Nu4DecompositionStatement
→ Toda (5.6) の ν₄ 分解

TodaProp511FiniteDimensionalStatement
→ Toda Proposition 5.11 の有限次元結果

Toda36Lemma514SigmaDoublePrimeBridgeStatement
→ Theorem 3.6 と Lemma 5.14 を結ぶ σ″ の関係
```

未対応 statement では rule name / type name fallback を維持する。

```text
Narrative
!= theorem inference
!= mathematical paraphrase guessing
!= provenance-free LLM proof
```

---

# 15. Narrative shared-dependency deduplication / wording

Phase 132-8 で Narrative 表示に `ProofStep` identity 単位の shared-dependency deduplication を追加した。

cycle guard と dedup state は別物として扱う。

```text
active_step_ids
→ 現在の再帰 stack 上の cycle guard

expanded_step_ids
→ Narrative で既に subtree を展開済みか
```

Phase 133 では表示文面を整理した。

最初の出現:

```text
subtree を通常展開
```

nested branch で既に展開済みの dependency:

```text
重複展開しない
```

root-level など、利用関係を表示すべき再参照:

```text
すでに得た ... を用いる。
```

導出の接続語:

```text
premise 1件
→ このことから

premise 2件以上
→ これらから
```

重要:

```text
Narrative subtree dedup
!= edge removal
!= node removal
!= provenance mutation
```

Trace / Outline / presentation graph は変更しない。

---

# 16. CLI proof presentation

generator-first:

```powershell
python main.py show-proof sigma_11
```

group-result-first:

```powershell
python main.py group-proof 9 7
python main.py group-proof 9 7 --depth 2
```

Phase 132 以降:

```powershell
python main.py group-proof 9 7 --mode trace
python main.py group-proof 9 7 --mode outline
python main.py group-proof 9 7 --mode narrative
python main.py group-proof 9 7 --depth 2 --mode narrative
```

`--mode` 省略時は `narrative`、`--depth` 省略時は `2`。

Trace / Outline / Narrative と depth 0 / 1 / 2 の明示指定 semantics は維持する。

```text
show-proof
→ generator から known-group identity を探す

group-proof
→ n,k query で得た group result から直接 replay / presentation
```

---

# 17. Web / CLI 共通 semantics

CLI と Web で数学エンジンを分岐させない。

Web group query は repository-backed result の場合のみ `proof_available=True` とし、result 直下に `Show proof` を表示する。

proof depth:

```text
0 / 1 / 2
```

proof view:

```text
Trace / Outline / Narrative
```

Trace は既存 structured replay view を使う。

Outline / Narrative は同じ renderer の出力を Web 用の薄い adapter に変換する。

Web adapter は数式 fragment を `data-latex` へ分離し、既存 KaTeX 表示経路を使う。

```text
Web adapter
!= proof graph builder
!= Narrative rule engine
!= second mathematical engine
```

---

# 18. Generator execution

既存 status:

```text
NONE
AMBIGUOUS
EXECUTED
```

Phase 126 以降、

```text
proof-scope relevance
applicability relevance
executable relevance
```

を区別する。

Phase 132–133 は execution semantics を変更していない。

---

# 19. parser 境界

operation query grammar の既存境界を維持する。

対応:

```text
二項 top-level composition
三項 top-level composition
E / H の generator operand
E / H の二項 composition operand
Delta の generator operand
```

未対応:

```text
四項以上
E(a o b o c)
H(a o b o c)
Delta(a o b o c)
Unicode ∘
一般再帰 parser
```

group-query CLI の `k` は Phase 130 で負値を許可したが、これは operation-query parser の一般化ではない。

---

# 20. regression / test collection

Phase 終了時の全体回帰は

```powershell
python -m pytest tests -q
```

を標準とする。

repo 内 backup directory に copied `test_*.py` を置かない。

backup は repo 外へ保存する。

最新 repository-wide regression:

```text
9980 passed in 807.31s (0:13:27)
```

---

# 21. Phase 130 完了境界

```text
low-dimensional standard query recovery
stem 1–6 stable/theorem-specific specialization
k=0 diagonal semantics
n=1 higher-group semantics
negative stem input
connectivity zero
pi_0 boundary information
negative dimension out-of-domain information
pi16_9 concrete sigma9 standard-query connection
repository non-mutation
stale negative-k CLI test correction
```

final regression:

```text
9308 passed in 577.02s (0:09:37)
```

---

# 22. Phase 131 完了境界

```text
group-result → ProofStep path audit
group-result proof replay core API
existing recursive provenance reuse
depth 0 / 1 / 2 replay
source_entry / proof_step identity preservation
zero-group replay
connectivity-zero replay
CLI group-proof
Web result → Show proof
pi_0 / negative-dimensional domain-only boundary preservation
existing show-proof semantics preservation
```

final regression:

```text
9333 passed in 583.64s (0:09:43)
```

---

# 23. Phase 132 完了境界

```text
existing proof narrative capability audit
actual ProofStep.premises edge semantics confirmation
TodaGroupProofPresentation
deterministic Outline renderer
deterministic Narrative renderer
safe statement rendering / fallback
shared dependency Narrative deduplication
CLI --mode trace|outline|narrative
Trace default compatibility
Web Trace / Outline / Narrative selector
Web KaTeX preservation
existing replay depth semantics reuse
proof graph / repository non-mutation
```

final regression:

```text
9392 passed in 587.98s (0:09:47)
```

Phase 132 は presentation layer の拡張であり、Toda の新しい数学定理、operation evaluator、proof search algorithm は追加していない。

---

# 24. Phase 133 完了境界

Phase 133 は post-Phase-132 workflow pressure 監査から、Narrative の可読性改善を実装対象として選んだ。

変更範囲:

```text
Narrative presentation only
```

実装内容:

```text
shared dependency 再参照文面の整理
単数 premise: このことから
複数 premise: これらから
代表 aggregate statement の human-readable label
低次元 / nu-family / Proposition 5.11 / Proposition 5.15 / sigma-family label
sigma 系 bridge / branch 表現の日本語化
```

不変:

```text
ProofStep
proof graph
Trace
Outline
repository roots
theorem facts
replay depth semantics
operation-query semantics
execution semantics
```

最終監査対象:

$$
\pi_6^3,\quad
\pi_8^5,\quad
\pi_{10}^4,\quad
\pi_{12}^5,\quad
\pi_{16}^9
$$

について depth 1 / 2 を確認し、代表的な内部 rule 名と旧 Narrative 文面が残っていないことを確認した。

focused regression:

```text
43 passed
```

repository-wide final:

```text
9403 passed in 605.52s (0:10:05)
```

Phase 133 完了。

---

# 25. Phase 134–136 完了境界

Phase 134–136 は proof semantics を変更せず、Narrative と Web presentation を段階的に改善した。

Phase 134:

```text
代表 theorem-specific Narrative
fact role / block role classification
Narrative document shell
REFERENCE block assembler
display-math / boundary / conclusion presentation primitives
```

Phase 135:

```text
Web Narrative display-math adapter
Web Narrative inline-math segmentation
inline KaTeX / display KaTeX mode separation
readability-oriented Web spacing
```

Phase 136-2 の代表対象:

$$
\pi_6^3=\mathbb Z/4\{\nu'\}.
$$

最終 Narrative では、Toda Lemma 5.2 の適用順序を数学的依存関係に合わせる。

まず

$$
2\eta_3=0
$$

を確認し、その後

$$
\{\eta_3,2\iota_4,\eta_4\}_1
$$

が定義できることを述べ、この bracket のある元を \(\nu'\) と定める。

Lemma 5.2 から

$$
\nu'\in\pi_6^3,
\qquad
H(\nu')=\eta_5,
\qquad
2\nu'=\eta_3^3
$$

を得る。

Toda Proposition 2.2 の右合成公式

$$
H(\alpha\circ E\beta)=H(\alpha)\circ E\beta
$$

を明示的に用い、

$$
H(\nu'\eta_6)
=
H(\nu'\circ E\eta_5)
=
H(\nu')\circ E\eta_5
=
\eta_5^2
$$

を表示する。

位数決定では次の EHP 完全列を表示する。

$$
\pi_7^3
\xrightarrow{H}
\pi_7^5
\xrightarrow{\Delta}
\pi_5^2
\xrightarrow{E}
\pi_6^3
\xrightarrow{H}
\pi_6^5.
$$

群構造決定では

$$
0
\longrightarrow
\pi_5^2
\xrightarrow{E}
\pi_6^3
\xrightarrow{H}
\pi_6^5
\longrightarrow
0
$$

を明示する。

重要な境界:

```text
Narrative ordering != new proof search
Narrative prose != new theorem fact
Toda Proposition 2.2 display != new inference semantics
short exact sequence display != new group calculation engine
Web KaTeX segmentation != mathematical normalization
```

Phase 136-2 focused regression:

```text
65 passed in 15.85s
```

repository-wide regression:

```text
9517 passed in 575.31s (0:09:35)
```

---

# 26. Phase 137 Web presentation cleanup 完了境界

Phase 136-2 の Web audit で確認した presentation-only pressure:

```text
Group query description:
pi_(n+k)^n
→ static mathematical text が KaTeX 未接続

Provenance / compact summary separator:
窶・Phase
窶・repository depth
窶・showing first
→ encoding / mojibake
```

Phase 137 では数学 semantics を変更せず、`templates/index.html` の presentation のみを修正した。

Group query の project quantity は

$$
\pi_{n+k}^{n}
$$

を既存 `data-latex` → `static/web_math.js` → KaTeX の経路へ渡す。

説明文中の数式なので既存 class

```text
group-proof-rendered-inline-math
```

を再利用し、`displayMode=False` とする。

文字化け separator は、過去の正常な template と同じ em dash `—` に戻す。

```text
— Phase
— repository depth
— showing first
```

`H(nu_prime)`、`E(nu_5)`、`sigma_11` などは operation / generator の入力 syntax 例なので plain text を維持する。

```text
static mathematical display
!= query input syntax example

Web presentation cleanup
!= mathematical semantics change
!= parser change
!= proof graph change
!= provenance change
```

focused regression:

```text
Phase 137-2: 3 passed in 6.96s
Phase 137-3 Web related: 56 passed in 20.23s
```

Phase 137-4 の manual Web verification では、

```text
\pi_{n+k}^{n} → KaTeX 表示
input syntax examples → plain text 維持
provenance separator → em dash
applicability compact summary → em dash
窶・ → 画面上に残らない
```

ことを確認した。

# 27. ドキュメント数式表示境界

README / design / development log / roadmap / proof records の display math は、GitHub Markdown 上で確実に数式表示されるよう `$$ ... $$` を標準とする。

inline math は既存どおり `\(...\)` を維持する。

```text
legacy display-math delimiter → $$ ... $$
inline \(...\) → 維持

documentation delimiter normalization
!= mathematical statement change
!= proof semantics change
```

Phase 137 final の repository-wide regression は、ドキュメント更新後の Phase-final step でのみ実行する。

# Phase 143 semantic Narrative 設計

Phase 143 では Narrative の数学的表示を、内部 `rule.name` に依存した fallback から、`ProofStep.conclusion` が保持する semantic statement の構造を読む表示へ移行した。

基本経路は次のとおり。

```text
ProofStep
→ conclusion semantic statement
→ statement fields / relation / membership / group structure
→ semantic LaTeX renderer
→ Narrative block / argument renderer
→ multi-argument Narrative
```

重要な境界:

```text
semantic statement
!= 新しい theorem fact

semantic renderer
!= inference rule

semantic rendering
!= proof search

Narrative ordering
!= proof graph mutation

rule-name fallback elimination
!= provenance elimination
```

Phase 143 の完了監査では、現行の

```text
_method_evidence_data(n, k)
→ presentation / blocks / sidecar / arguments
→ render_toda_group_proof_narrative_multi_argument_markdown()
```

という実際の Narrative 入口を使用した。

監査結果:

```text
scanned groups: 128
scanned presentation nodes: 1663
rule-name fallback occurrences: 0
distinct fallback rule names: 0
render errors: 0
```

したがって、Phase 143 で監査した current-entrypoint Narrative については、内部 rule-name fallback を通常の数学表示として残さないことを現在の不変条件とする。

## semantic statement と dependency の役割分離

statement が nested theorem / bridge / short exact sequence 等を dependency として保持していても、親 statement の renderer が dependency の数学的内容を勝手に再構成してはならない。

```text
statement の直接 semantic fields
→ statement 自身の表示

dependency ProofStep
→ proof graph / Narrative ordering

dependency の存在
!= 親 statement の追加数学的結論
```

この原則により、保存された fields に零端点がない短完全列を renderer が推測して補う、といった表示上の theorem synthesis を避ける。

## direct premise suppression / relocation / preservation

Phase 143 終盤では、semantic statement の表示と既存の Narrative 重複抑制・relocation の境界を整理した。

特に direct premise は次の分類を混同しない。

```text
redundant direct premise
relocatable direct premise
context-hidden step
DERIVATION source block として保持すべき semantic premise
```

`context_hidden_step_ids` は引き続き最優先で非表示とする。

一方、DERIVATION source block として保持対象になった block 内の `redundant_direct_premise_step_ids` は、semantic な導出根拠そのものを失わないため表示を保持できる。

ただし `relocated_direct_premise_ids` の suppression は一律に解除しない。これにより、例えば

$$
2\nu_5=E^2\nu'
$$

は元位置と relocation 先に二重表示されず、既存の依存順序に従って一度だけ表示される。

また

$$
\pi_{15}^{8}
\cong
\mathbb Z/8\{E\sigma'\}
\oplus
\mathbb Z\{\sigma_8\}
$$

という transported decomposition は、その後の標準順序

$$
\pi_{15}^{8}
=
\mathbb Z\{\sigma_8\}
\oplus
\mathbb Z/8\{E\sigma'\}
$$

とは異なる導出上の意味を持つため、両方を保持する。

```text
transported decomposition
!= final standard-order conclusion

semantic preservation
!= duplicate preservation

relocation
!= deletion of proof provenance
```

Phase 143 は presentation semantics の改善であり、Toda の新しい数学定理、group-query semantics、operation evaluator、proof search algorithm は追加していない。

---

# 28. Phase 144 generic Narrative / ownership boundary

Phase 144 は、Phase 143 で semantic statement rendering を整備した後、証明全体の
Narrative を一般構造だけで組み立てる際の ownership（所有関係）、argument boundary
（議論境界）、contribution ordering（寄与の順序）を監査した。

基本経路は次のとおり。

```text
TodaGroupResult
→ existing ProofStep provenance
→ replay / complete replay
→ TodaGroupProofPresentation
→ semantic sidecar
→ Narrative blocks
→ Narrative arguments
→ proof chains / contributions
→ contribution-aware generic Narrative renderer
```

この経路は新しい proof search ではない。

```text
complete replay
!= new theorem search

semantic closure
!= theorem synthesis

argument ownership
!= proof edge ownership

Narrative contribution placement
!= proof graph mutation
```

## explicit depth と complete replay

Narrative では explicit positive depth の presentation に必要な semantic dependency が
bounded replay の外側にある場合がある。このため complete replay API を用いる経路を持つ。

ただし depth 0 は root のみを要求する明示的境界であり、complete replay へ切り替えない。

```text
Narrative + explicit depth > 0
→ 必要に応じて complete replay から presentation を構築

Narrative + depth 0
→ bounded depth-0 replay を維持
```

Phase 144 final regression repair では、この depth 0 境界を `main.py` で復元した。

## R25-30-R3 ownership / argument-boundary endpoint

Phase 144-6 の技術調査は R25-30-R3 を endpoint とする。

6代表群の current inventory:

```text
pi_6^3:  selected=6   participating=6/6   detached=0/0    transport=1
pi_8^5:  selected=10  participating=7/7   detached=3/3    transport=1
pi_10^4: selected=22  participating=0/0   detached=22/0   transport=2
pi_12^5: selected=46  participating=2/2   detached=44/0   transport=4
pi_15^8: selected=54  participating=10/10 detached=44/0   transport=4
pi_16^9: selected=54  participating=10/10 detached=44/0   transport=4
```

aggregate:

```text
selected=192
participating=35
detached=157
detached_insertable=3
missing=0
```

R25-30-R3 では、対象3ケースの boundary classification と existing child Argument pair が
一致した。したがって `detached_insertable=3` を ownership leak とみなして旧
`detached_insertable=0` へ戻してはならない。

```text
historical R5 fixed-count snapshot
!= current semantic gate
```

## result-reuse pressure の分離

$\pi_{15}^{8}$、$\pi_{16}^{9}$ などで group-structure / definition の owned entry が
大きな proof subtree を再帰的に展開する現象が確認された。

これは

```text
argument-boundary leak
```

ではなく、

```text
already-established result の proof subtree を再展開する result-reuse problem
```

として分離する。

Phase 144 ではこの問題の一般解を実装しない。具体的な証明で必要になった Phase 146
以降に、その1課題だけを解く最小一般規則として扱う。

## Phase 144 regression evidence

canonical final repository-wide run:

```text
10298 collected
10273 passed
25 failed
2321.20s (0:38:41)
```

25 failures は R5-39〜R5-43 の historical completion / fixed-count snapshot に集中した。
production renderer は変更せず、固定件数を新しい固定件数へ置換することもせず、
current structural invariant に maintenance した。

focused maintenance regression:

```text
66 passed in 1308.82s (0:21:48)
```

この maintenance 後は repository-wide suite を再実行していない。そのため設計記録では
「全体 10298 passed」とは記載しない。

## Phase 145 / Phase 146+ 境界

Phase 145:

```text
default presentation → Narrative
default depth → 2
```

のみを扱う。

Phase 145 では result reuse、ownership の追加一般化、statement type の先回り実装を行わない。

Phase 146 以降:

```text
具体的に通したい証明
→ その証明で不足している1課題を特定
→ target-specific special case ではなく最小一般規則で解く
→ focused regression
→ 既存証明を壊さない
```

を1 Phaseずつ繰り返す。

# 29. Phase 145 完了境界

Phase 145 の機能変更は group-proof の default presentation だけである。

```text
default mode
→ Narrative

default depth
→ 2
```

CLI の default は概念的に次と同値である。

```powershell
python main.py group-proof n k --mode narrative --depth 2
```

Web group-proof も同じ default を使用する。

明示指定は従来どおり維持する。

```text
--mode trace
--mode outline
--mode narrative

--depth 0
--depth 1
--depth 2
```

したがって:

```text
default presentation change
!= replay semantics change
!= proof graph change
!= proof provenance change
!= theorem fact change
!= new proof search
```

Phase 145 の repository cleanup では historical Phase artifact を
`archive/phases/` 以下へ整理した。

cleanup 後の canonical test collection で、既存 test suite に

```text
tests.test_* package import
bare test_* import
```

の2形式が共存していることを確認した。

最終的な test-only compatibility boundary は:

```text
tests/__init__.py
→ tests package を明示

tests/conftest.py
→ tests directory を import path に追加
```

である。

これは既存 canonical test 本体の大量書き換えを避けるための test infrastructure であり、
production import semantics を変更しない。

Phase 145 focused regression:

```text
46 passed in 15.62s
```

canonical collection:

```text
10303 tests collected
```

repository-wide final:

```text
10303 passed in 2375.31s (0:39:35)
```

Phase 145 完了。

Phase 146 以降は1 Phase につき1つの concrete issue を選び、その issue に必要な
最小一般規則だけを追加する。

```text
one concrete issue
→ minimum general rule
→ focused regression
→ existing proof preservation
```

Phase 145 では result-reuse、追加の ownership model、将来 proof のためだけの
semantic rule、一般 evaluator は実装していない。

---

# 30. Phase 146 historical Narrative difference audit / root-cause boundary

Phase 146 は、現在の generic Narrative が historical Phase 136-2 の
$\pi_6^3=\mathbb Z/4\{\nu'\}$ Narrative と同等の数学的説明構造を一般規則だけで
再構成できているかを監査した。

Phase 146 の基準 historical commit は

```text
908e24db89669750949fa9ad149f5e306ac05546
```

とする。

## current generic route boundary

現行 $\pi_6^3$ public Narrative は target-specific な route gate を通るが、その gate 内部では

```text
presentation
→ semantic sidecar
→ Narrative blocks
→ Narrative arguments
→ contribution-aware generic renderer
```

を使用する。

Phase 146-5 では current public $\pi_6^3$ output と current generic contribution renderer
output の exact parity を確認した。

これは

```text
current public pi_6^3
=
current generic pi_6^3
```

を意味するが、

```text
current generic pi_6^3
=
historical Phase 136-2 Narrative
```

を意味しない。

したがって route parity と historical quality parity を区別する。

## Phase 146-7 generic prose repair

Phase 146-7 では `render_toda_group_proof_narrative_argument_header_method_section()` に
generic argument-purpose prose fusion を追加した。

従来の

```text
$X$ の位数を決定する.
そのために、次の完全列を考える.
```

を、primary exactness method が argument に対応する場合に

```text
$X$ の位数を決定するために、次の完全列を考える.
```

と一文に統合する。

これは target-specific な $\pi_6^3$ 文面ではなく argument role と method component に基づく
一般表示規則である。

focused regression:

```text
11 passed
```

existing $\pi_6^3$ public-route regression:

```text
4 passed
```

Phase 146-7 では EHP naming、exactness ownership、contribution ordering、Reference prose、
equation numbering は変更していない。

## Phase 146-8 historical full structural diff

Phase 146-8 では historical Phase 136-2 と current generic Narrative を構造比較した。

raw unit inventory:

```text
historical units: 17
current units: 82
PRESERVED: 0
LOST: 17
ADDED: 47
MOVED: 0
DUPLICATED: 35
REWORDED: 0
UNMATCHED: 0

sequence-related units:
historical 4
current 44

[R#] units:
historical 8
current 1
```

ただし historical と current では unit 粒度が異なるため、

```text
PRESERVED=0
LOST=17
```

を「数学的事実が17件失われた」と解釈してはならない。

この audit の有効な結論は、historical と current の文章構造に大きな差があり、
特に exactness の過剰展開、Reference provenance の縮退、重複、配置順の差が
定量的に存在することである。

## Phase 146-9 root-cause classification

Phase 146-9 は production code を変更せず、Phase 146-8 で整理した12の visible difference
families を内部原因へ分類した。

$\pi_6^3$ current argument diagnostics:

```text
establish_group_structure:
  method_evidence=3
  components=1
  primary=True
  primary_windows=3
  contributions=2

establish_order:
  method_evidence=2
  components=1
  primary=True
  primary_windows=2
  contributions=2

establish_definition:
  method_evidence=0
  components=0
  primary=False
  primary_windows=0
  contributions=0
```

したがって order argument の問題は

```text
primary exactness component が存在しない
```

ことではない。

正しくは、

```text
current argument-method ownership / selection
!= historical proof-purpose ownership / explanatory placement
```

である。

また renderer layer では

```text
base multi-argument chars: 1377
contribution-connected chars: 1579
contribution renderer changes output: True
argument builder uses direct dependency indices: True
contribution renderer performs post-render insertion: True
```

を確認した。

## six root causes

Phase 146-8 の12 visible difference families は次の6 root causes に集約する。

### RC1 — Argument-method ownership

historical proof-purpose と current argument-method ownership の差。

主対象:

```text
order argument と主要 EHP 完全列の ownership
method introduction の一部
```

### RC2 — Recursive exactness evidence exposure

primary method に吸収されない recursive exactness evidence が body / contribution として
露出する。

主対象:

```text
主要完全列の範囲選択
補助完全列の本文抑制
exactness contribution 重複の一部
```

### RC3 — Contribution ownership / insertion ordering

argument dependency narration と contribution の ownership / post-render insertion が別経路である。

主対象:

```text
contribution 重複の一部
dependency order に沿った式配置
map-property chain の配置
short exact sequence → group structure の順序
```

### RC4 — Generic provenance / reason prose

compact Reference は保持されても historical の

```text
[R#] の n=... の場合より
```

のような derived-fact reason prose を一般的に再構成できていない。

主対象:

```text
Reference section の詳細
Reference → derived fact の理由付け
definition argument の理由文章の一部
```

### RC5 — EHP semantic naming

generic transition は

```text
次の完全列を考える
```

と表示するが、stored semantics から

```text
EHP 完全列
```

という method family name をまだ一般的に表示しない。

### RC6 — Final equation numbering / prose formatting

equation numbering は selected / ordered Narrative stream の下流にある。

したがって RC1〜RC5 より先に target-specific tag rule で historical numbering を再現してはならない。

## dependency order

修正順序は

```text
RC1
→ RC2
→ RC3
→ RC4
→ RC5
→ RC6
```

とする。

RC6 は selection / ordering の下流なので最後に扱う。

## Phase 146 closure boundary

Phase 146 で実施した production change は Phase 146-7 の generic argument-purpose prose fusion
のみである。

Phase 146-8 / 146-9 は audit only であり、次は変更していない。

```text
pi_6^3 public route gate
exactness ownership
contribution selection
generic provenance rendering
EHP semantic naming
final equation numbering
```

Phase 146 完了時点では $\pi_6^3$ 専用 route gate を削除しない。

Phase 147 以降は上記 root cause を1件ずつ一般規則として扱う。

```text
one root cause
→ minimum general rule
→ focused regression
→ historical/current structural comparison
→ existing proof preservation
```

Phase 146 closure documentation 自体は production semantics を変更しない。

---

# Phase 148 設計完了記録 — Recursive exactness evidence exposure

Phase 148 / RC2 の責務は、既存 proof provenance に含まれる recursive exactness evidence
（再帰的な完全性証拠）を Narrative 本文へどこまで展開するかを一般規則として決定することである。

## exposure pipeline

```text
ProofStep / provenance
→ method evidence
→ RC1: Argument-method ownership
→ RC2: exactness exposure classification
→ Narrative body
```

Phase 148 では exactness method component を次の3分類で扱う。

```text
OWNED_PRIMARY
UNOWNED_RECURSIVE
AMBIGUOUS_RELEVANT
```

### OWNED_PRIMARY

Argument が primary method として所有する component。

```text
raw EXACTNESS_WINDOW
→ 本文では抑制

DERIVED_SHORT_EXACT_SEQUENCE / higher-level method contribution
→ ownership と contribution rule に従って保持可能

provenance
→ 保持
```

### UNOWNED_RECURSIVE

recursive provenance から到達するが、その Argument の primary method として所有されない component。

```text
body contribution
→ 自動展開しない

raw exactness
→ 自動展開しない

derived short exact sequence
→ 自動展開しない

provenance
→ 保持
```

### AMBIGUOUS_RELEVANT

複数 component が直接 relevant で一意な owner を決定できない場合。

```text
conservative fallback
→ 既存表示を維持
→ renderer が ownership を推測しない
```

## semantic closure boundary

Web Narrative は selected depth の bounded replay を入力とする。

```text
selected bounded replay
→ semantic closure
→ Narrative renderer
```

complete replay を Web Narrative の入力として常用しない。

depth 0 では semantic closure は identity とする。

positive depth では、既存 provenance のうち Narrative に必要な最小 dependency のみを補う。
Phase 148 で追加した calculation closure は、

```text
ORDER relation
→ direct EQUALITY premise
→ その equality の direct EQUALITY premises
```

という graph-level relation に限定する。

これにより $\pi_6^3$ の位数計算に必要な equality chain は補う一方、
group-structure context や Hopf chain の無関係な equality を一括で展開しない。

既存の registered definition semantic closure は維持する。

```text
semantic closure
!= new proof search
!= new theorem fact
!= proof edge creation
```

## Phase 149 との境界

Phase 148 は exposure を扱い、ordering は扱わない。

```text
RC2:
どの exactness evidence を本文に出すか

RC3:
表示対象 contribution をどの順序に置くか
```

したがって、

```text
short exact sequence
→ final group conclusion
```

のような数学書としての説明順序は Phase 149 / RC3 の責務とする。

---

<!-- PHASE149_RC3_CLOSURE -->
# Phase 149 RC3 Narrative contribution ordering

Phase 149 は Phase 146 で RC3 と分類した Narrative contribution ordering（Narrative 寄与の配置順）を扱う。

責務の分離は次のとおり。

```text
RC1:
Narrative Argument
→ primary method ownership

RC2:
primary / recursive method evidence
→ exposure classification

RC3:
visible owned evidence
→ Narrative placement
```

RC3 の一般順序は次を目標とする。

```text
method
→ evidence
→ derivation
→ conclusion
```

`OWNED_PRIMARY` exactness evidence は、RC2 の既存 contribution 抽出・filter をそのまま利用し、owner Argument の conclusion より前へ配置する。

重要なのは、global Narrative block order を proof の説明順そのものと見なさないことである。

```text
global block order
!= Argument-local explanatory order
```

Phase 149 RC3-3 では、`OWNED_PRIMARY` exactness contribution を body loop の前に収集し、元 exactness block 位置での重複表示を抑止し、owner conclusion block の直前へ挿入する。

この処理は presentation-only である。

```text
exactness placement
!= exactness exposure reclassification
!= ProofStep relocation
!= proof edge mutation
!= theorem fact creation
```

6代表群

$$
\pi_6^3,\quad
\pi_8^5,\quad
\pi_10^4,\quad
\pi_12^5,\quad
\pi_15^8,\quad
\pi_16^9
$$

の RC3-4 audit では全 Argument で ordering invariant が成立した。

```text
failures=[]
AUDIT_RESULT=PASS
```

focused regression:

```text
57 passed in 10.85s
```

repository-wide final regression:

```text
﻿10416 passed in 1315.93s (0:21:55)
```

なお、$\pi_6^3$ の order Argument 内で

$$
2\nu'=\eta_3^3
$$

という derived calculation の表示位置をさらに自然にできる余地はある。しかしこれは RC3 の exactness evidence placement とは異なる calculation / derivation internal ordering の問題であり、Phase 149 では変更しない。
---

<!-- PHASE150_CLOSURE -->
# 34. Phase 150 完了境界 — generic provenance / reason prose

Phase 150 は Phase 146 で RC4 と分類した `Generic provenance / reason prose`
を対象とした。

数学的 ground truth は引き続き次である。

```text
ProofStep.conclusion
ProofStep.premises
ProofStep.inference_rule
existing recursive provenance
```

Phase 150 の reason layer は、これらの既存 provenance から Narrative に必要な
「なぜこの結論を述べられるか」を型付きで表す presentation-side structure である。

```text
typed Narrative reason
!= new theorem fact
!= new proof edge
!= new proof search
!= theorem ranking
```

reason prose は typed reason から生成する。複数の異なる typed reason instance が
同一の汎用 sentence を生成する場合がある。その場合、文字列を一意化して1回だけ表示することを
正しさの条件にはしない。

正しい表示契約は sentence $s$ ごとに

$$
\#\{\text{typed reason instances rendering to }s\}
=
\#\{\text{occurrences of }s\text{ in Narrative}\}
$$

である。

6代表群の multiplicity audit では、問題となった共通 sentence について次を確認した。

```text
pi_6^3:  typed=3, rendered=3
pi_8^5:  typed=3, rendered=3
pi_10^4: typed=2, rendered=2
pi_12^5: typed=2, rendered=2
pi_15^8: typed=1, rendered=1
pi_16^9: typed=3, rendered=3
```

したがって Phase 150 final repair は production renderer を変更せず、historical test contract
を instance multiplicity に合わせた。

## renderer-route 境界

Phase 150 では段階的 generic route 移行を進めた結果、複数 renderer の共存そのものが
群間の表示差を生み、代表群ごとの修正では一般化の評価が難しいことを確認した。

したがって Phase 150 では group-by-group migration を継続しない。

```text
Phase 150
→ RC4 reason semantics / prose の確立
→ route coexistence を architectural pressure として確認
→ incremental migration をここで停止

Phase 151
→ whole-population generic baseline
```

Phase 151 では対象群を同じ generic renderer へ強制的に通して観測するが、
public renderer selection は変更しない。

```text
generic baseline audit
!= public route switch
!= dedicated renderer deletion
!= legacy fallback deletion
```

## test strategy

Phase 150 final full regression は closure baseline として全 `tests` を1回実行した。

```text
10478 passed in 2505.44s (0:41:45)
pytest exit code: 0
wall-clock elapsed: 00:41:56.919
```

この約42分の historical full suite を、今後すべての Phase 終了時に必須とはしない。

通常の開発サイクルは次とする。

```text
RC / repair
→ focused tests

Phase closure
→ focused tests
→ maintained canonical regression

major integration / release milestone
→ complete historical regression
```

test suite 自体についても、後続 Phase で現在の保証を重複して検証する historical test、
audit-only test、旧 renderer contract を整理し、canonical regression を明示する。

ただし test 数の削減そのものを目的とせず、現在の仕様・数学的 provenance・public API の
保証を維持することを優先する。

## Phase 151 境界

Phase 151 は `All-Group Generic Baseline` とする。

目的:

```text
同一 population
→ 同一 generic route
→ 同一 depth / observation conditions
→ success / failure / fallback / semantic inventory を一括取得
```

Phase 151 では generic renderer の欠陥をその場で群別修正しない。
まず全体像を取得し、欠陥分類を次 Phase の入力とする。

---

# 35. 現行 regression 方針

旧方針の「Phase 終了時に必ず repository-wide full regression」は Phase 150 closure をもって
運用上の標準から外す。

現行方針:

```text
focused regression
→ 日常の実装・repair

canonical regression
→ Phase closure の標準

complete historical regression
→ renderer 統一、public API 大変更、release 等の大きな節目
```

完全な historical suite は削除せず、必要な節目で再実行できる状態を維持する。

---

<!-- PHASE153_CLOSURE -->
# Phase 153 — Narrative Reference selection / granularity 設計

Phase 153 は Narrative の Reference（参照）を、単なる provenance の列挙ではなく、
「本文で実際に使用される外部結果の境界」として扱う一般規則を整理した。

新しい Toda theorem fact、ProofStep、proof edge、proof search は追加していない。

## Reference の基本境界

Phase 153 後の設計では、Narrative Reference は次を満たす。

```text
external Reference
!= current root theorem

displayed Reference
→ proof ancestry / proof-use に基づく

marker-bearing route
→ 本文で使用された [Rk] だけを残す

generic no-marker route
→ 実際に表示へ参加した step identity から Reference を残す
```

current `presentation.root_step` が持つ `LiteratureReference` は、renderer route に
依存せず external Reference section へ出さない。

```text
root theorem provenance
!= external supporting Reference
```

## literature-reference identity

同じ文献 locator が label 違いで複数表現される場合、locator を canonical identity として扱う。

```text
both locators exist
→ locator equality を優先

otherwise
→ full LiteratureReference equality
```

これにより、たとえば同じ `(5.2)` を異なる label で保持する step があっても、
root Reference exclusion の意味論を route 間で一致させる。

## Reference granularity

Reference は aggregate root 全体を機械的に選ぶのではなく、consumer が実際に利用する
proof boundary を優先する。

aggregate conclusion の複数 component のうち、consumer の generator / structure に対応する
component が一意に特定できる場合、その component を表示対象とする。

```text
aggregate provenance
→ consumer-relevant component
→ external Reference statement
```

これは theorem fact の分解や変更ではなく presentation granularity である。

## Reference reuse

本文中で exact step がすでに Reference statement として表示されている場合、その step は
再利用可能な proof boundary として扱う。

```text
displayed Reference step
+ premises
→ [Rk] を用いる
→ recursive derivation expansion を抑制
```

title-only Reference はこの boundary にはしない。

```text
Reference reuse
!= ProofStep deletion
!= premise deletion
!= provenance deletion
```

## used-Reference filtering

marker-bearing route では本文に現れる `[Rk]` を実使用集合とし、未使用 Reference を除外した後、
番号を連続化する。

generic route では explicit marker が無いため、表示へ参加した argument / local-body /
contribution step identity を用いて Reference 使用を帰属する。

specialized route では既存 marker mapping を壊さないことを優先し、root exclusion によって
mapping が変質する場合は specialized renderer 自身の Reference section を保持する。

## 112-group closure invariant

depth 2 の標準対象

$$
n=2,\ldots,15,
\qquad
k=0,\ldots,7
$$

について次を closure invariant とした。

```text
render errors = 0
Reference numbering is contiguous
root LiteratureReference is not external
body marker never points to a missing Reference
marker-bearing route has no unused displayed Reference
```

最終 audit:

```text
scanned groups: 112
render errors: 0
violations: 0
```

## Phase 153 の境界

```text
Reference selection / granularity
!= theorem selection
!= theorem ranking
!= proof search
!= proof graph mutation
!= proof-prose quality completion
```

接続語重複、内部 rule-name の露出、英語 statement、重複 scalar 表現、句読点などの
proof-prose generation は Phase 154 へ送る。

historical test suite の consolidation（整理）は独立 maintenance とし、Phase 154 の
proof-prose 改善を妨げる前提条件にはしない。

<!-- PHASE154_DOCUMENTATION_CLOSURE -->
# Phase 154 設計完了記録 — Proof prose generation refinement

Phase 154 は proof provenance（証明の由来）や theorem fact（定理事実）を増やす Phase ではなく、
既存 proof graph から生成される public Narrative prose（公開証明本文）の品質を一般規則で
改善する Phase とした。

## 設計境界

ground truth は引き続き次である。

```text
ProofStep.conclusion
ProofStep.premises
ProofStep.inference_rule
existing recursive provenance
LiteratureReference
```

Phase 154 の prose layer はこれらを表示へ変換する presentation rule であり、

```text
proof-prose refinement
!= new theorem fact

proof-prose refinement
!= proof edge creation

proof-prose refinement
!= proof search

Reference-to-body linkage
!= Reference selection rewrite

sentence deduplication
!= provenance deletion
```

とする。

## internal fallback leakage

public Narrative に inference-rule name や statement type-name がそのまま露出する場合は、
stored semantic information から generic prose を生成する。

特に、

```text
Toda (5.6) nu_4 decomposition integration
\text{ is injective}
\text{ is exact}
```

のような internal / English representation を public prose へ残さない。

## semantic duplication

同じ semantic reason が複数の typed reason instance から同一文へ写る場合でも、
public Narrative で同じ `FINAL_RESULT_DERIVATION` 文を反復表示しない。

```text
multiple typed final reasons
→ one shared final-result prose sentence
```

これは reason sidecar の情報を削除することではない。

```text
reason provenance
→ preserved

visible duplicate sentence
→ suppressed
```

## Reference-to-proof-body linkage

Reference marker は単に独立行で

```text
[Rk]を用いる.
```

と置くのではなく、Proof graph 上で一意に対応する visible non-root consumer が存在する場合、
その consumer sentence へ接続する。

例:

```text
[R2]より, $\nu_4$ の分解写像は同型写像である.
```

root-only Reference のように一意 consumer へ結び付けられない場合は neutral use sentence を
維持する。

```text
unique graph-backed consumer
→ [Rk]より, consumer fact.

no unique safe consumer
→ [Rk]を用いる.
```

Reference selection / granularity 自体は Phase 153 の責務を維持する。

## transition / sentence composition

Argument purpose と exactness method introduction、semantic fact、Reference reuse を結合する際は、
生成元同士の punctuation contract を一致させる。

Phase 154-R6 で、

```text
そのために, 次の完全列を考える.
以上より, ...
(1) と (2) より, ...
```

へ統一した。

これにより、異なる renderer source が旧 `、` と新 `, ` を混在させたために発生する
sentence fusion failure を防ぐ。

## punctuation policy

public Narrative prose の punctuation は次で統一する。

```text
comma  = ", "
period = "."
```

ただし以下は対象外である。

```text
TeX / inline math
display math
literature title punctuation
mathematical list punctuation
```

したがって `Proposition 5.8.` の period や TeX 内部の comma を prose normalization で
変更しない。

## 112-group closure invariant

対象:

$$
n=2,\ldots,15,
\qquad
k=0,\ldots,7,
$$

depth 2 の public Narrative 112群。

Phase 154 closure invariant:

```text
render exception = 0
transition repetition = 0
semantic duplication = 0
internal fallback leakage = 0
English prose = 0
Reference linkage violation = 0
ordering violation = 0
Japanese prose punctuation violation = 0
```

最終監査:

```text
scanned groups: 112
rendered groups: 112
exceptions: 0
violations: 0

transition_repetition: 0
semantic_duplication: 0
internal_fallback_leakage: 0
english_prose: 0
reference_linkage: 0
ordering: 0
punctuation: 0
```

全112群で ASCII comma prose / ASCII period prose の双方が存在することも確認した。

## dedicated route heading audit

$\pi_8^5$ と $\pi_{15}^8$ の専用 renderer について、closure audit の substring count が

```text
## 証明対象
```

を

```text
## 証明
```

として誤検出した。

production defect ではなく audit defect であり、exact line match に変更して、

```text
## 証明対象
<
## 使用する結果
<
## 証明
```

を確認した。

この修正は audit code のみで、production renderer は変更していない。

## test-contract maintenance boundary

Phase 154 の current contract と矛盾した historical tests は test-only で更新した。

```text
Phase 149:
(1) と (2) より、 → (1) と (2) より,

Phase 150:
同一 FINAL_RESULT_DERIVATION prose の重複表示
→ public Narrative では1回

Phase 150 reason vocabulary:
、 → ,
```

production semantics を historical expectation に戻さない。

## Phase 154 完了境界

documentation closure 時点で次は完了している。

```text
focused Phase 154 regression: PASS
ordering / reason boundary regression: PASS
112-group closure audit: PASS
punctuation closure audit: PASS
```

ただし repository-wide final full regression はまだ実行していない。

したがって、

```text
documentation closure complete
!= Phase 154 final regression complete
```

とする。

Phase 154 の正式 completion は次の Phase-final full regression 後に確定する。

<!-- PHASE155_TEST_CONSOLIDATION_DESIGN_START -->
# Phase 155 Test Suite Consolidation 設計

Phase155 は test architecture の maintenance Phase であり、Toda theorem fact、`ProofStep`、proof search、Narrative の数学的意味を変更しない。

最終 boundary:

```text
total: 10384
routine: 10382
audit-only: 2
```

routine regression は file-based shard + checkpoint/resume とする。

final audit-only:

```text
Phase153 all-group public Reference structural audit
Phase97 representative cross-layer provenance audit
```

Phase144 の historical completion/source-shape audit は current contract ではないため削除した。

Phase153 の exact selected-statement/body duplicate audit は 117件を観測した。ただしこれは test-suite defect ではなく Phase156 の Reference statement relevance / minimal display の pressure である。

```text
117 duplicate observations
→ Phase156 input
!= Phase155 production defect
```
<!-- PHASE155_TEST_CONSOLIDATION_DESIGN_END -->

<!-- PHASE158_DOCUMENTATION_CLOSURE -->
# Phase 158 設計確定 — public Narrative contract の統一

Phase 158 では数学的 `ProofStep`、theorem fact、proof search を変更対象とせず、public Narrative の表示経路と最終表示契約を統一した。

## public depth-2 route

`max_depth >= 2` の public Narrative は群名による dedicated route 選択を行わず、次の generic route を利用する。

```text
TodaGroupProofPresentation
→ semantic closure
→ semantic sidecar
→ Narrative blocks
→ Narrative arguments
→ contribution-aware multi-argument renderer
→ public wrapper
→ Phase 158 public-contract normalization
```

`max_depth < 2` の direct API fallback は既存互換性のため維持する。

この境界は、

```text
public route unification
!= proof graph rewrite
!= theorem fact replacement
!= new proof search
```

である。

## public document shell

depth 2 以上の public Narrative は最終的に次の shell へ正規化する。

```text
# Group proof narrative

## 証明対象

...

## 使用する結果

...

---

## 証明

...

□
```

`## 使用する結果` の直後に旧来表示されていた

```text
使用する結果を先にまとめる.
```

は削除し、Reference section は `[R1]` から直接開始する。

Reference attribution、fixed statement / proof-internal boundary、Reference numbering 自体はこの shell 正規化では変更しない。

## equation numbering

Phase 158 の equation numbering は、proof-item numbering と明確に分離する。

equation numbering:

```text
\tag{1}
...
(1) より,
```

proof-item numbering:

```text
(3), (4) より,
```

後者は `\tag{N}` との対応を要求しない。

式番号を付与する条件は次である。

```text
1. 現在の Narrative に source equation が実際に表示されている
2. その source が後続 derivation で利用される
3. source equation が citation connector より前に表示される
```

したがって、

```text
structural transition が存在するだけ
→ equation tag を付けない

後続参照がない terminal equation
→ equation tag を付けない

source より先に reference connector が来る
→ forward reference を作らない
```

最終 public normalization では unreferenced / duplicate equation tag を除外し、保持する番号を compact にする。

## generic ordering

Phase 158-R5 では、群固有の `(n,k)` 判定ではなく、

```text
depth >= 2
and
root conclusion を支える structured Narrative Argument が存在する
```

ことを public generic ordering route の条件として用いる。

これにより、たとえば

$$
\pi_7^4
$$

では $\nu_4$ decomposition premise が root group conclusion より前に置かれ、

$$
\pi_{15}^8
$$

では transported decomposition が final group conclusion より前に置かれる。

これは表示順の規則であり、

```text
Narrative ordering
!= ProofStep.premises の変更
!= presentation edge の変更
!= semantic fact の追加
```

である。

## Web boundary

Web Narrative depth 2 は public Markdown と同じ generic route と ordering contract を利用する。

`---` は separator として parse し、terminal `□` は通常 text segment として扱う。

Web adapter は別の数学 engine を持たない。

## Phase 158 closure boundary

Phase 158-R5-6 repair1 後の verification:

```text
direct repaired-contract verification:
32 passed

R5 focused closure regression:
45 passed

git diff --check:
PASS
```

repository-wide pytest は利用者判断により実行しない。

Phase 158 の closure 根拠は public Narrative に直接関係する focused verification とする。

## Phase 159 との境界

Phase 159 は表示統一の続きではなく、数学的 proof coverage の不足を低い stem から順に埋める。

開始順序:

$$
(k,n)=(1,2),(1,3),(1,4),\ldots
$$

その後、

$$
k=2,3,\ldots
$$

へ進む。

各 group 専用規則を追加するのではなく、

```text
current proof replay
→ missing mathematical step の特定
→ 再利用可能な一般規則へ抽象化
→ focused verification
→ 次の n
```

とする。

stable range に達した後は、必要に応じて Freudenthal suspension theorem による suspension isomorphism を利用し、非安定部分を主対象とする。


<!-- PHASE159_STABLE_TRANSPORT_DESIGN -->
# Phase 159 完了時の stable / unstable 設計境界

Phase 159 では $k=1$ の低次群を用いて public proof の構造を監査し、stable transport（安定移送）を全 stem に一般化するための設計境界を確定した。全 stem への実装拡張は Phase 159 では行わない。

## stable range の判定

対象を

$$
\pi_{n+k}^{n}
$$

とする。Toda (4.5) / Freudenthal suspension theorem による安定移送を使用する境界は

$$
n\ge k+2
$$

とする。したがって routing（経路選択）の設計は

```text
n < k + 2
→ unstable proof を既存 proof provenance から詳細に構成する

n >= k + 2
→ generic stable transport を使用する
```

である。

## canonical stable base

各 stem $k$ について stable range の入口を

$$
n_0=k+2
$$

とし、canonical stable base（標準安定基点）を

$$
\pi_{2k+2}^{k+2}
$$

とする。target $\pi_{n+k}^{n}$ が stable range にあるとき、

$$
E^{n-k-2}:
\pi_{2k+2}^{k+2}
\overset{\cong}{\longrightarrow}
\pi_{n+k}^{n}
$$

によって群構造を移送する。

## generic layer と family-specific layer

将来の generic stable transport は次の責務へ分離する。

```text
is_in_toda_stable_range(target)
canonical_stable_base(target)
build_toda_45_stable_transport_step(base, target)
resolve_stable_generator_transport(base_generator, target)
```

前3項の stable-range 判定、canonical base 選択、群構造の suspension transport は stem に依存しない generic rule とする。最後の generator transport / normalization は family-specific rule とする。

例えば $k=1$ では

$$
E^{n-3}\eta_3=\eta_n
$$

という $\eta$-family の正規化を行う。$\nu$-family、$\sigma$-family などは、それぞれ既存 literature fact と generator convention に基づく別の normalization を持ち得る。

したがって

```text
group-structure stable transport
→ generic

generator naming / normalization
→ family-specific
```

を設計原則とする。

## Reference と specialization の境界

Toda (4.5) の Reference は general form（一般形）のまま表示する。target 固有の変数代入は proof body で行う。

```text
Reference
→ literature statement の general form

proof body
→ target への specialization
```

Reference を target 固有の文へ書き換えて literature statement 自体を変形したように見せてはならない。

## semantic identity

proof fact の同一性・依存関係・重複抑制は rendered prose の文字列一致で決めない。既存 statement identity、semantic key、ProofStep provenance など意味構造に基づいて扱う。文章の normalization は presentation layer に限定する。

## Phase 159 と次 Phase の境界

Phase 159 では $k=1$ の実装を prototype として監査し、$\pi_3^2$ と $\pi_4^3$ の public proof を完成点とする。

次 Phase では、まず現行 $k=1$ 実装のうち generic layer に持ち上げられる部分を inventory し、その後に最小限の generic stable transport を実装する。Phase 159 の段階では他 stem の production route を先取りして変更しない。


<!-- PHASE160_DOCUMENTATION_CLOSURE -->
# Phase 160 — generic stable transport の現行設計

Phase 159 で設計した stable transport（安定移送）を Phase 160 で production path へ実装した。ここから先は本節を stable transport の現行設計とする。

## stable target semantics

対象を

$$
\pi_{n+k}^{n}
$$

とする。

stable range（安定域）は

$$
n\ge k+2
$$

であり、canonical stable base（標準安定基点）は

$$
n_0=k+2,
\qquad
\pi_{2k+2}^{k+2}
$$

である。

target への transport exponent（移送回数）は

$$
n-n_0=n-k-2
$$

である。

したがって canonical transport は

$$
E^{n-k-2}:
\pi_{2k+2}^{k+2}
\overset{\cong}{\longrightarrow}
\pi_{n+k}^{n}
$$

となる。

この意味論は `stable_rules.py` の target / stem / canonical-base helper と、Toda (4.5) の concrete specialization builder で共有する。

## Toda (4.5) specialization

literature Reference は Toda (4.5) の general form（一般形）を保持する。

```text
Reference
→ n >= k + 2 の一般形

proof body
→ canonical base と concrete target への代入
```

target 固有の式を Reference statement 自体へ書き戻さない。

`build_canonical_toda_stable_transport_map()` と `build_canonical_toda_45_isomorphism_step()` は、canonical base から target への structural suspension map と Toda (4.5) isomorphism step を構成する。

## generic finite-cyclic transport

`FiniteCyclicGroup` の stable transport は family 名に依存しない。

入力:

```text
canonical-base group relation
Toda (4.5) isomorphism
```

出力:

```text
same cyclic order
+
IteratedSuspension(source_generator, exponent)
```

したがって例えば

$$
\pi_8^5=\mathbb Z/8\{\nu_5\}
$$

を transport した直後の generator は、概念的には

$$
E^{n-5}\nu_5
$$

であり、この generic layer 自体はそれを $\nu_n$ と同一視しない。

重要な境界:

```text
cyclic order transport
→ generic

named family generator
→ family-specific normalization
```

## generic zero-group transport

4-stem と 5-stem は `FiniteCyclicGroup(order=1)` として表現しない。

Toda (4.5) isomorphism

$$
E^r:G\overset{\cong}{\longrightarrow}H
$$

と

$$
G=0
$$

から

$$
H=0
$$

を得る generic zero-group transport を用いる。

この規則は `TodaPrimaryGroupZeroStatement` をそのまま扱う。

## family-specific normalization

Phase 160 では group transport と generator naming を分離した。

### eta family

1-stem:

$$
E^{n-3}\eta_3=\eta_n.
$$

2-stem:

$$
E^{n-4}\eta_4^2=\eta_n^2.
$$

内部では $\eta_n^2$ が `Composition` として保持される場合があるが、public group notation は power notation（冪記法）へ canonicalize する。

### nu family

3-stem:

$$
E^{n-5}\nu_5=\nu_n.
$$

6-stem:

$$
E^{n-8}\nu_8^2=\nu_n^2.
$$

6-stem は特に

```text
generic finite-cyclic transport
→ transported generator E^(n-8)(nu_8^2)
→ nu-squared normalization
```

の2段階を明示的に分ける。

### sigma family

7-stem:

$$
E^{n-9}\sigma_9=\sigma_n.
$$

Phase 160-R6 で generic finite-cyclic transport と sigma-family normalization を分離した。

## stem 1–7 の production stable architecture

stable target の canonical base は次のとおり。

| stem | canonical stable base | stable family |
| --- | --- | --- |
| 1 | $\pi_4^3=\mathbb Z/2\{\eta_3\}$ | $\mathbb Z/2\{\eta_n\}$ |
| 2 | $\pi_6^4=\mathbb Z/2\{\eta_4^2\}$ | $\mathbb Z/2\{\eta_n^2\}$ |
| 3 | $\pi_8^5=\mathbb Z/8\{\nu_5\}$ | $\mathbb Z/8\{\nu_n\}$ |
| 4 | $\pi_{10}^6=0$ | $0$ |
| 5 | $\pi_{12}^7=0$ | $0$ |
| 6 | $\pi_{14}^8=\mathbb Z/2\{\nu_8^2\}$ | $\mathbb Z/2\{\nu_n^2\}$ |
| 7 | $\pi_{16}^9=\mathbb Z/16\{\sigma_9\}$ | $\mathbb Z/16\{\sigma_n\}$ |

production path は、既存 theorem-specific transport rule を削除して互換性を壊すのではなく、current production builder が generic rule を使うように接続する。旧専用 rule は compatibility（互換性）のため残してよい。

## public Narrative

stable public Narrative は stem ごとの専用証明本文を作らず、共通 shape を用いる。

```text
## 証明対象

## 使用する結果
[R1] Toda (4.5) general form
[R2] canonical base result

---

## 証明
canonical base
concrete Toda (4.5) specialization
generator transport / normalization（必要な場合）
target group result

□
```

4-stem と 5-stem は generator equation を持たず、zero group の同型移送だけを表示する。

canonical base 自身では stable transport wrapper を起動しない。

## public generator canonicalization

internal expression（内部式）と public notation（公開表記）を区別する。

内部では例えば

$$
\eta_n\eta_{n+1},
\qquad
\nu_n\nu_{n+3}
$$

を `Composition` として保持できる。

public group display では

$$
\eta_n^2,
\qquad
\nu_n^2
$$

を使用する。

この canonicalization は、

```text
Group query Result
Group proof Conclusion
Narrative target / conclusion
```

で整合させる。

一方 `render_toda_expression_latex()` の raw expression rendering は変更しない。証明途中で expanded composition（展開形）が数学的に必要なら、その表現を保持する。

```text
public group canonicalization
!= semantic expression rewrite
!= proof fact mutation
```

## Phase 160 の非目標

Phase 160 では以下を実装しない。

```text
unrestricted stable theorem database
generic DirectSumGroup stable transport
generic FreeCyclicGroup stable transport
arbitrary generator-family normalization
unstable proof の stable transport による置換
new theorem roots
second proof engine
```

このプログラムの主対象は unstable homotopy groups（非安定ホモトピー群）であり、stable range は詳細な非安定計算を無限に繰り返さないための共通移送として扱う。

## 次 Phase との境界

Phase 160 で stem 1–7 の stable transport infrastructure は共通化できた。

次 Phase では stable layer をさらに一般化するのではなく、unstable range

$$
n<k+2
$$

の proof audit に戻る。

Phase 159 で stem 1 の低次境界を確認済みなので、残る低次 unstable target を $(k,n)$ の小さい順に監査し、実際に不足する数学規則だけを追加する。

repository-wide full pytest は Phase 160 closure では実行しない。

## Phase 161 — Concrete Backward Goal Schema と provenance 境界

Phase 161 は、非安定 EHP の具体的目標

$$
E:\pi_4^2\xrightarrow{\cong}\pi_5^3
$$

に対する Backward Chaining（後向き推論）の最小縦断実装を導入した。現行の Production Rule（前向き推論規則）を変更せず、逆向きの目標分解と前向きの証明構築を別の責務として扱う。

### 目標展開

```text
E isomorphism
├── E injective
│   └── Delta_6 zero
│       └── H_6 surjective
└── E surjective
    └── H_5 zero
        └── Delta_5 injective
```

EHP 完全性は4箇所で別々の部分目標・証拠として保持する。

$$
\pi_5^3\xrightarrow{H}\pi_5^5\xrightarrow{\Delta}\pi_3^2,
$$
$$
\pi_4^2\xrightarrow{E}\pi_5^3\xrightarrow{H}\pi_5^5,
$$
$$
\pi_6^3\xrightarrow{H}\pi_6^5\xrightarrow{\Delta}\pi_4^2,
$$
$$
\pi_6^5\xrightarrow{\Delta}\pi_4^2\xrightarrow{E}\pi_5^3.
$$

末端規則には既存の `TodaProp51FiniteDimensionalStatement` と $H(\nu')=\eta_5$ の `Relation` など、既存の推論済み前提を照合する。`conclusion_builder` と `match_guard` は既存規則のものを再利用し、文字列による数学命題判定には置き換えない。

### 証明再構築と信頼境界

R5 は完成済み同型の `ProofStep` を入力せず、承認された前提証拠から7規則を適用し、新たな `ProofRule.INFERENCE` の導出を構築する。ただし、元となる文献前提の `ProofStep` の祖先の正しさは R5 だけでは保証されない。

R6 でこの限界を明示した。R7 の検証付き入口では、`INFERENCE` の依存関係を再帰的にたどり、既存規則から結論を再計算する。未承認の `GIVEN`、根拠のない `INFERENCE`、改変された結論、循環する祖先は拒否する。`GIVEN` の出所承認は外部に残る Trust Boundary（信頼境界）であり、文献事実の数学的妥当性を形式証明したことにはならない。R7 は R5 の従来 API を変更せず、検証済み経路を追加する。

### 制限と次 Phase

本実装は $E:\pi_4^2\to\pi_5^3$ に特化した7規則の再構築である。任意群の規則選択、文献命題の自律探索、無制限な AND/OR 探索、public Narrative との統合は実装していない。次の Phase 162 では、R7 で検証した導出結果と既存の共通 Narrative Renderer の接続を先に監査する。新しい別系統の renderer を作らない。

### 検証方針

利用者指定により Phase 161 終了時にも repository-wide full pytest を行わない。局所検証は R2–R5 合計17件、R6 4件、R7+R6 回帰10件の PASS 報告がある（R6 は重複して実行されている）。全体テスト成功は主張しない。

<!-- PHASE162_CLOSURE_20261010 -->

## Phase 162 終了時点の設計境界と Phase 163 方針（2026-10-10）

Phase 162 の $\pi_5^3$ 監査では、既存の `ProofStep` を利用した証明再構築と、結論から任意の出典を独立に発見する一般探索とを区別する必要が明確になった。既存の `phase161_r5_backward_proof_reconstruction.py` と `phase162_pi5_3_backward_selection.py` は限定された目標と既存の証拠に依存する。Reference と Proof 本文の表示だけを調整しても証明木の根拠選択の正しさは保証されない。

### 登録情報の責務分担

- `proof.py`: `LiteratureReference`、`ProofStep`、`InferenceRule` などの基礎型。
- `toda_rules.py` 等: 数学的 Statement と Production Rule。
- `theorem_facts.py` 等: 文献由来の事実。
- `proof_repository.py` / `standard_repository.py`: 証明ステップの登録・検索。
- `toda_literature_statement_boundary.py`: fixed statement と proof-internal fact の区別、および一部 component `order`。

これらは単一の検索・利用可能性判定契約ではない。特に component の `order` を、そのまま「先に証明済み」の証拠と解釈してはならない。

### Phase 163 の統一 Registry に必要な情報

文献識別子、命題識別子、主張識別子、構造化 Statement、適用範囲、出典 locator、文献内の掲載位置、同一命題内の主張順、主張が利用可能になる証明完了位置、proof-internal / fixed-statement 区分、依存関係、既存 `ProofStep` と `InferenceRule` の対応を共通に扱う。掲載位置と証明完了位置は異なる情報として保持する。複数の主張を同時に証明する場合は単純な直列番号で先行主張を利用可能にせず、依存グラフと同時証明の境界を扱う。

資料の順序や証明完了位置が不明なら `unknown` として扱い、推測した番号で証明探索を許可しない。異なる文献の間には自動的な全順序を置かない。自己参照、未証明の後続命題の引用、循環依存、同一命題の未確立主張の流用は探索の候補選択で拒否する設計とする。既に証明済みの fixed statement を引用する場合、その内部の Lemma や proof steps を引用のたびに自動展開しない。

### Phase 境界

Phase 162 は問題の特定と監査記録で区切る。Phase 163 は全登録 Statement の棚卸し・共通 ID・来歴・順序と利用資格のデータ整備および共通検索までとし、一般証明探索の成功を主張しない。一般 Backward Search の規則選択・候補評価への統合は後続 Phase とする。既存 API と数学的推論規則の変更は必要最小限とする。

## Phase 164 — 証明生成・表示経路の共通化（2026-10-13 確定）

### Phase の目的と設計境界

Phase 164 は、個別の証明文章や数学的導出を完成させる Phase ではない。既存の Statement Registry（命題台帳）、Proof Repository（証明保管庫）、Backward Search（逆向き探索）、ProofStep Factory（証明ステップ生成）、Presentation（表示用データ）、Renderer（文章表示）および Web 入口の接続を共通化することを目的とする。

主要経路は次のとおりである。

`Statement Registry / 引用資格境界 → Proof Repository / Backward Search → ProofStep Factory → Presentation → Common Renderer → Web`

Generator・Group・Operation の Resolver も既存の対象経路に共通に接続する。ただし、すべての照会が必ず Backward Search を実行するとは限らない。用途別の正当な経路差分まで統一を理由に消さない。

### ProofStep の生成責務

- アプリケーション層の直接生成と既存の GIVEN / INFERENCE は共通 Factory 経由に移行する。
- `proof.py` は依存関係の根であり、中核コンストラクタ8箇所と中核推論委譲2箇所は内部処理として維持する。Factory から逆方向に `proof.py` を参照させる循環 import は作らない。
- 表示専用の ProofStep projection は実証済みの推論とは扱わない。既存の rule と provenance（来歴）状態を保持し、数学的認証に昇格させない。
- R8-R7 の既定 AST（構文木）監査範囲で、未移行の本番直接生成呼び出しは0件。`replace()` 65箇所は文字列置換38、対象外 dataclass 25、ScalarSum 専用1、ProofStep 分岐保護1に分類した。

### 表示経路の責務

- Web の Group proof は共通 Presentation / Renderer を経由する。Trace・Outline・Narrative という表示方式の差異は保持する。
- Narrative の重複する EHP 部分完全列と接続句は、共通の表示正規化で扱う。証明木、推論、引用境界に変更を加えない。
- R9-R2 の代表例 $\pi_5^3$（depth 2）では EHP 完全列1本、重複部分列0件、接続句重複なしを実行時に確認した。
- 数学的根拠、生成元の対応の説明、各群ごとの Narrative 品質は後続 Phase で改善する。表示の文章品質を Phase 164 の完了条件へ混入しない。

### 検証上の制約

限定テストの実績として R8-R7 は77 PASS、R9-R2 は17 PASS。いずれも全体 pytest の成功を意味しない。Phase 164 の文書区切りに際して全体 pytest および追加 pytest は実施しない（ユーザー指定）。静的監査の除外対象や動的別名経路について完全網羅を主張しない。未検証の GIVEN / INFERENCE と Toda 原典掲載位置は未検証のまま維持する。

<!-- PHASE165_FINAL_CLOSURE_20261019 -->

## Phase 165 — 旧経路整理と現行探索境界の確定（2026-10-19）

### 設計上の確定事項

- 群別の旧証明選択・旧 Replay・個別 Renderer を、未検証の証明に対する fallback として戻さない。
- 共通 Backward Search（逆向き証明探索）は、型付き Goal（目標）、引用資格を持つ命題識別子、展開規則を必要とする。これらが不足すれば fail-closed（未証明のまま停止）とする。
- Reference（文献固定命題）と Proof Internal（内部導出）を分離する。どの成分か確定できない集約命題を、Reference 選択処理が無条件に昇格させない。
- Presentation / Renderer は既存の証明ステップを表示する責務に限定し、数学的前提の不足を補完しない。

### 完了判定と限界

旧契約に依存するテストをバックアップして退避し、現行契約のテストを保持・更新した。Phase 165 終了時の全体テストは `python -m pytest tests -q --tb=short` で **3525 PASS、FAIL 0、ERROR 0**。これは活動中のテスト集合の整合性を示すもので、退避したテストの合格や、任意群についての証明自動発見を保証しない。次 Phase では個別群の Goal / 出典 / 規則 / 生成元輸送 / 公開 Narrative を現行共通経路で検証する。


<!-- PHASE166_HANDOFF_20261021 -->
## Phase 166 終了時の設計境界（2026-10-21）

Phase 166 の開発作業をここで停止する。**全体 pytest 合格による正式な完了認定ではない。** 命題台帳の掲載順、型付き目標、共通探索、公開 Web 表示を結び付けるための限定監査を実施したが、任意の Goal の Proof 完成までは保証しない。

- 群構造データベースから構築した Goal（証明目標）は、証明事実そのものではない。Goal の LaTeX 表示成功と ProofStep の数学的導出を厳密に区別する。
- `generic-complete-proof` は探索結果の完了状態を示すが、日本語 Narrative の意味的な説明・出典対応・重複排除まで保証するとは扱わない。
- `generic-partial-proof` と `partial_result=true` は証明未完成として明示する。$\pi_5^3$ の Web view は R3-AU-12 で Goal を表示した一方、導出済み ProofStep は0件だった。
- 文献の掲載順による参照可否と、型付き主張の一致・推論規則の適用を混同しない。旧方式の使用順制限や新たな「照合未完了」資格判定は復活させない。
- $\pi_4^3$ の群構造を既知の数学的前提として用いる場合、別の証明への参照にあたり、その群構造の証明木を必ず再帰的に表示する必要はない。文献固定命題と内部導出の境界は保つ。

Phase 167 では ProofStep と Reference の出自を調べ、共通 Renderer のみ必要最小限修正する。証明本文に規則の内部名を漏らさず、根拠のある日本語説明を生成する。

<!-- PHASE168_FINAL_CLOSURE_20261025 -->

## Phase 168 — 現行共通 Narrative と信頼境界の確定（2026-10-25）

### 実装済みの公開経路

現在の標準的な群の完全証明は、以下の単一の責務分担で生成する。

```text
型付き Goal（登録済み証明対象）と文献掲載順
    ↓
Backward Search（逆向き証明探索）
    ↓
Proof Tree（採用された ProofStep と依存関係）
    ↓
Proof Tree verification（完全証明の検証境界）
    ↓
Proof Narrative Model（実際に使用した証明・引用の射影）
    ↓
共通 Renderer（本文・Reference・Citation の出力）
    ↓
標準 Web 表示
```

- 標準 Web 入口：`web_group_proof.py::build_standard_web_group_proof_view()`。
- 完全証明の検証境界：`phase168_r3_41p13_trust_boundary/verification.py::verify_proof_tree_for_narrative()`。R3-41P19 では、完全証明の対象群と結論の一致を検査する条件を追加した。
- Model 接続：`phase168_r3_4_link_bridge.py::build_linked_proof_narrative_model()` と `phase168_r3_3_proof_narrative_model.py`。
- 共通文章・文献表示：`phase168_r3_5_model_renderer.py::render_model_backed_narrative_markdown()` と Reference projection（参照本文射影）。

完全証明の検証では、GIVEN（既出の固定命題）の選別済み出典・掲載順と、INFERENCE（推論）の既存規則・祖先を点検する。引用対象の命題識別子は登録 Goal から解決し、後続命題・自己参照を引用可能な証拠として扱わない。旧「使用順」制限を再導入せず、`publication_position` と必要な `component_position` に基づく文献順を用いる。未解決の結果は partial として表示し、完成へ昇格させない。

### Origin Observation の制約と保持する防御

R3-41P17 で `proof_origin_capture.py` に Factory 出力と探索で採用された ProofStep のオブジェクト同一性を観測する機能を追加した。しかし R3-41P18 は、外部から記録を自己申告して偽の INFERENCE を受け入れさせ得ること、複数探索が同一 Observation に集約され得ること、実験的 handoff では別の Bridge wrapper や不整合な target を受け入れ得ることを確認した。**Observation は数学的な証明書ではない。**

R3-41P19 で対象群の検証を加えたのは標準の検証関数である。実験的な origin handoff に残る境界問題まで解決したとは主張しない。標準 Web の matcher を使った検証は維持する。任意の利用者定義 `InferenceRule`、外部供給 `RegistryBridgeResult`、出典文献そのものの数学的真実性について一般認証したという意味でもない。

Renderer / Typed Projection に残る `_stable_eta_renaming_shape()` と `prop42_exactness_indices()` による数学的な形状検査2箇所は、直接渡された未検証 Model の不正な表示を拒否する互換性防御として維持する。証明を新規生成する責務を Renderer へ移すこととは区別する。これらを撤去する場合は、全ての呼び出し元に対する真正性保証を先に成立させる必要がある。

### Reference と代表群の不変条件

- $\pi_3^2=\mathbb Z\{\eta_2\}$：INFERENCE 13、GIVEN 5、計18 ProofStep。
- $\pi_4^3=\mathbb Z/2\{\eta_3\}$：INFERENCE 19、GIVEN 6、計25 ProofStep。
- $\pi_5^4=\mathbb Z/2\{\eta_4\}$：INFERENCE 7、GIVEN 3、計10 ProofStep。

$\pi_5^4$ は、Proposition 5.1 に登録された $\pi_4^3$ の**群構造**と Toda (4.5) の $(n,m,k)=(3,4,1)$ への適用を使用する。$\pi_4^3$ の完成証明木そのものを再帰的に再利用・再表示する必要はない。生成元は $E(\eta_3)=\eta_4$ として扱う。

上記3群について証明本文・Reference・Citation は固定基準と全文一致し、GIVEN 14件の文献順が PASS した。Phase 168 最終限定 pytest は **86 PASS**、現行 `tests/` および Phase 168 関連回帰を対象とする終了テストは **3546 PASS、FAIL 0、ERROR 0**。歴史的な退避テストを含む無制限の repository-wide pytest や、未監査の全群についての証明成立を主張しない。

### Phase 境界

Phase 168 の正式な完了対象は、標準公開経路の Proof Tree / Reference / Narrative の整合性、数学的な防御の維持、上記最終回帰である。2-stem の全群の証明完成は本 Phase の完了条件として認定しない。次工程は残存する partial 群の型付き導出・出典資格の確認から始め、旧方式の個別 Renderer や固定文章を復活させない。

<!-- PHASE169_R10ET_DOCUMENT_CLOSEOUT_20261028 -->

## Phase 169 R10ET — 共通 Definition と証明に必要な引用の境界（2026-10-28）

### 本番探索での Definition（定義）の責務

R10ET-R5D は `phase165_r52_r9_shared_math.py::shared_expansion_provider()` の探索候補順を修正した。型付き `GeneratorImage`（生成元の写像像）が安定範囲の共通 Definition に厳密に適合するときだけ、独立に replay（推論再生）できるゼロ前提の `GoalExpansion` を優先する。不適合な対象では既存の探索候補を引き続き使用する。新たな個別 family 名や群ごとの例外規則は導入しない。

共通 Definition は生成元像の既存の型付き関係に適用するものであり、群構造、Toda (4.5) の同型性、あるいは異なる生成元の同一性を独力で確定するものではない。DB prior（既知の群構造）と Toda (4.5) は、完成証明で実際に使用される場合、独立した引用付き `GIVEN` の祖先として保持する。`HyoujiGen.csv` を含む既存の生成元データとの接続を維持し、表示文字列・family 名を証明根拠の代替にしない。個別 Definition の旧台帳エントリは、この作業で削除していない。

### Proof Tree と Narrative / Reference の責務分離

R10ET-R6C は `phase168_r3_3_proof_narrative_model.py` の `root_ancestor_step_indices()` と `build_proof_narrative_model()`、`phase168_r3_5_model_renderer.py` の `render_model_backed_narrative_markdown()` を更新した。**完成証明**の本文と Reference の対象は、選択された root（結論）から前提をたどって到達できる検証済み ProofStep のみとする。これにより、探索結果中に保持された別経路の未使用 `GIVEN` を Reference に混入させない。採用引用には連続した番号を割り当てる。

Proof Tree 自体・探索結果の全 `ProofStep`・既存の Trust Boundary（信頼境界）・部分証明の観測情報は変更しない。表示層は命題・推論・DB 情報を新たに生成しない。モデルの祖先関係が不正であれば fail-closed（安全側で拒否）とし、文献名の一致だけで祖先とみなさない。

### 監査結果と適用範囲

R6B の $\pi_{10}^{8}$ は `COMPLETE`・Trust PASS、共通 Definition 適用可能4件・正規実使用4件、残存依存0件だった。元の Reference [R1] は `sphere.csv` の `(n=7,k=2)` の未使用 DB prior で、結論の祖先に含まれなかった。R6C は9個の検索済み ProofStep を保持しながら、root から到達できる8個だけを完成証明に表示し、実際の証明に必要な `(n=4,k=2)` の DB prior と Toda `(4.5)` を [R1]・[R2] として表示した。

R6D は R6 の `certify_reviewed_production()` のソース同一性確認を R6C 後の正しい Model / Renderer に対応させ、元の19ケース監査を改めて実行した。必須16件・追加3件の `CHECK=PASS`、Trust PASS、共通 Definition が適用可能な個別引用依存の残件0を確認した。限定 pytest は R6C 43 PASS、R6D の R6 再実行24 PASS。Git index と既存変更は保持された。全体 pytest は Phase 169 の末尾まで実行していない。

### Phase 169 との境界

以上は R10ET の対象範囲に限る検証であり、任意の $(n,k)$ の完成証明・全登録命題の数学的真理・過去の個別 Definition 登録削除を保証しない。Phase 169 全体の Closeout、対象範囲の回帰テスト選定、Git に登録する監査生成物の整理は後続の工程とする。長い自動生成ファイルを一括 `git add -A` で登録しない運用上の注意を維持する。

<!-- PHASE169_FINAL_CLOSEOUT_20261028 -->

## Phase 169 終了時の設計境界（2026-10-28）

Phase 169 の正式な終了対象は、R10ET までにレビューした型付き逆向き探索、生成元像の共通 Definition、安定懸垂輸送、巡回群・直和群・合成生成元の証明表示、および完成証明の root 祖先に限定した本文・Reference の射影である。R10ET 文書区切りに記した「全体 pytest は未実施」はその時点の記録であり、本節の最終テストによって更新された。

共通 Definition は、安定範囲に適合する `GeneratorImage` の正規 `INFERENCE` を本番探索で優先する。既存の群構造 DB prior、Toda (4.5) による同型、生成元関係などの数学的前提を置き換えない。`HyoujiGen.csv` の型付き生成元データとの整合を保ち、特定の family 名に依存する新規規則を追加しない。

完全証明では、検証済み Proof Tree の root から到達できる ProofStep だけを Proof Narrative Model / Reference に射影する。Proof Tree 全体を削除せず、未完成証明の出力を変更しない。標準 Web の検証器を経ず、任意に与えられた Model を正式な証明と認証しない。Origin Observation も認証の代替とはしない。

最終テスト Gate は、関連回帰 **67 PASS**、現行アクティブ `tests/` **3546 PASS**、FAIL 0、ERROR 0、終了コード0、Git index 保全 PASS。Gate 自身の限定テスト **8 PASS**。実行コマンドは `python -B -m pytest -q --tb=short --disable-warnings -p no:cacheprovider tests`。`tests/conftest.py` の Phase 155 audit-only nodeid 除外を維持し、退避した歴史的テストを無制限に収集していない。

**認定境界：** この合格は Phase 169 で対象にしたコード・証明表示・有限個の回帰の終了判定であり、任意の stem や全登録群の自動証明、文献上の全命題の独立した形式認証を意味しない。残存する数学的・DB 上の未達事項は次 Phase の監査で確定する。既存 API、Trust Boundary、退避テストの扱いを変更しない。

<!-- PHASE170_FINAL_DOCUMENT_CLOSEOUT_20261029 -->

## Phase 170 — $n=2$ の登録済み33件に対する型付き輸送と証明検証（2026-10-29）

### 本番探索の数学的根拠と責務

Phase 170 は、登録済み DB の $n=2$、$1\le k\le33$ を対象とし、$m=k+2$ で先行する $\pi_m^3$ の型付き群構造と Toda (5.2) の $\eta_2\circ-:\pi_m^3\xrightarrow{\cong}\pi_m^2$ を組み合わせる Backward Search（逆向き証明探索）経路を拡張した。巡回群および直和群の構造と生成元の対応は型付き演算により検査し、DB の表示文字列や生成元名の一致のみでは推論を採用しない。DB の群構造が Goal（証明目標）として与えられたことを、その Goal の証明済み GIVEN（既知の前提）とみなさない。

特に $\pi_{14}^{2}$ では先行する $\pi_{14}^{3}$ の直和分解に現れる $\varepsilon_3\circ\nu_{11}$ と目標の $\nu'\circ\bar\nu_6$ が文字列として異なる。Toda (7.12) の型付き等式 $\varepsilon_3\circ\nu_{11}=\nu'\circ\bar\nu_6$ を出典付きの**独立した第3前提**として Proof Tree に加え、同じ生成元であるとの無根拠な仮定を拒否する。Toda (5.2)、先行群構造、Toda (7.12) の各根拠は既存の探索・引用採用・検証境界を通る。

Toda (7.12) の引用は `sources/toda/Toda_07_2.tex` の採用済み TeX 転写を厳密に照合し、`HyoujiGen.csv` の生成元 ID から型付き等式を構築する。文献の掲載位置はこの転写データ内の順序であり、Toda 原著の刊行版の位置や記述が独立に校訂・認証されたことは意味しない。転写が一致しない場合は fail-closed（安全側で拒否）とする。

### 標準 Web 経路と監査範囲

公開経路は従来どおり、登録された型付き Goal → Backward Search → 検証済み Proof Tree → Proof Narrative Model → 共通 Renderer → Web とする。`phase170_r3_r8_n2_exhaustive_audit/audit.py` の独立 Worker によって各 $k=1,\ldots,33$ を再探索し、`generic-complete-proof`、`partial_result=False`、`open_goals=0`、検証済みステップと描画行の存在を確認した。R3-R10R1 の全33件で `COMPLETE_AND_WEB_VERIFIED`、未完了0件、既存追跡ファイルの変更なしだった。

Phase 170 の終了 Gate では、同じ33件の監査レポートを個々の Worker 行まで検査したうえで、現行アクティブ `tests/` の pytest **3,546 PASS**（2026-10-29、34.94秒、終了コード0）、`FULL_SUITE_PASS`、`tracked_unchanged=True` を確認した。監査パッケージの追加による Git HEAD の変更は、数学的な本体ファイルの変更と区別して検証した。ここで「全体テスト」と呼ぶのは現行 `tests/` であり、退避された歴史的テストを含む無制限の全ファイル収集ではない。

### 認定しない範囲

登録済み $n=2$ の33件以外の Goal、全ての $n\ge3$、すべての stem、Toda 原著の全命題の数学的真理、任意の外部 `InferenceRule` は認定対象外である。旧 Renderer や個別生成元名に依存した例外的な証明を復活させず、既存 API と Trust Boundary を維持する。

## Phase 171 — $\pi_6^3$ の完成証明と表示責務の境界（2026-10-31、Closeout R2）

Phase 171 は登録済み $\pi_6^3=\mathbb Z/4\{\nu'\}$ の公開 Backward Search（逆向き探索）を `complete` に到達させた。EHP 完全列の厳密性から $E:\pi_5^2\to\pi_6^3$ の単射性、$H:\pi_6^3\to\pi_6^5$ の全射性を導き、両端が位数2の群であることから

$$
0\longrightarrow\pi_5^2\xrightarrow{E}\pi_6^3\xrightarrow{H}\pi_6^5\longrightarrow0
$$

を証明する。したがって $|\pi_6^3|=4$ であり、出典に基づいて推論した $2\nu'=E(\eta_2^3)\ne0$ によって $\operatorname{ord}(\nu')=4$ を得る。結論を表示するために未証明の `GIVEN` を追加する方法は採用しない。

Proof Tree（証明木）は数学的事実・推論と依存を保持し、Proof Narrative Model（証明文章モデル）は実際の root ancestry（根の祖先）に結びつく引用のみを投影する。Renderer（表示器）はその検証済み内容だけを文章化する。Phase 171 R20R12 は証明済みの位数計算を文章化し、R20R13/R2 は同一の引用を持つ連続した検証済み $\eta$ 懸垂等式のみを統合する。複数の空行を越えることは許すが、非空の別の推論や異なる引用を飛び越えることはできない。ピリオド後の改行処理は完成証明の本文に限定し、Reference や数式内部を変更しない。

R20R13R3 はインストーラの HEAD 固定条件を内容検査へ変更し、R20R13R4 はテストの行頭一致判定を修正した。Closeout R1R1 は Phase 169 R3Z の歴史的な28ステップ固定を、探索結果との同一性、推論根、`complete`、未解決目標ゼロの検査へ置換した。これは数学的結果・探索規則・Reference に手を加えない**テストの意味的保守**である。限定回帰は Windows で 88 PASS、インストーラ検査 5 PASS。

Phase 171 の完全証明には引用8件が対応する。`generic-complete-proof`、出典に結びつく証明木、Web 表示が一致することを完了認定の対象とする。Phase 終了時の現行アクティブ `tests/` 全体 pytest は本 R2 の時点では未実施であり、Phase 171 正式終了はその Gate の検証後に確定する。$E(\eta_5)=\eta_6$ の同義反復、長い $H$ の途中式、全射性の重複、`DB prior` の説明改善は Phase 172 の表示品質候補であって、証明木に未証明の事実を追加する理由にはならない。


<!-- PHASE171_FINAL_CLOSEOUT_20261031 -->

## Phase 171 — 最終終了 Gate（2026-10-31）

Phase 171 終了時に現行アクティブ `tests/` の全体 pytest を1回実行し、**3,546 PASS（3546 passed in 125.50s (0:02:05)、終了コード0）** を確認した。R2 文書5ファイルは元の内容に対して審査済みの追加のみであり、この正式終了節も既存本文のバイト列を保存して追加した。数理的な Proof Tree、Backward Search、Reference、Renderer の本番実装を変更していない。

完成認定対象は登録済み $\pi_6^3=\mathbb Z/4\{\nu'\}$ の Proof Tree と公開 Web 経路に限る。Phase 172 の表示改善候補を Phase 171 の完成条件に混入させない。

<!-- PHASE172_FINAL_CLOSEOUT_20261031 -->

## Phase 172 — 表示専用射影と終了時の不変条件（2026-10-31）

Phase 172 は、Phase 171 で完成した $\pi_6^3=\mathbb Z/4\{\nu'\}$ の証明に対して、**検証済み Proof Tree を入力とする表示専用 Projection（射影処理）**を整備した。Backward Search（後向き証明探索）、Inference Rule（推論規則）、既存の `GIVEN`、群構造、文献出典の採用規則は変更していない。

- R1 は既存 Web Narrative（証明叙述）、Reference（引用）、50件の ProofStep（証明段階）を照合した監査である。
- R2 は引用済み `GeneratorSuspension`（生成元懸垂）から検証済みの直接等式と対称等式の重複表示を省く。`η_5` と `η₅` は印字名ではなく、`GeneratorSymbol`（型付き生成元識別子）・次元・始域・終域で対応を検証する。証明段階は残す。
- R3 は $H(\nu'\eta_6)=\eta_5^2$ に至る既証明の Hopf 導出の途中式を短縮し、Definition（定義）、Proposition 2.2、(5.3) の出典に対応する本文と最終等式を維持する。
- R4 は同じ型付き Hopf 写像の全射性を二度表示しない。後の全射性の推論依存と先行する検証済みの全射性を確認した場合だけ後者の重複行を抑制する。
- R5 は `ADOPTED_DATABASE_PRIOR` の出典を Web Reference 見出しに限って日本語化する。元の `DB prior: sphere.csv` locator と対応する ProofStep、Reference 番号、Trust Boundary（証明の検証境界）は保持する。`[参考: Proposition ...]` は独立の文献定理として採用したことを意味しない。

これらは型付きの根・祖先・Citation（引用対応）と表示順を検査し、欠損・不整合・未完成の証明では不正な圧縮を行わない **fail-closed（不確実な場合は変換しない）**方式である。特定の生成元名による新しい数学的例外や、新しい公理を追加しない。

R6 Closeout（終了監査）では、`develop` の `6ac7fd8a4ccdf628a0767a0d865dddcf88bbd92a` に対し、限定 pytest 10セット、公開 Web 検証5群（$\pi_3^2,\pi_4^3,\pi_5^3,\pi_6^4,\pi_6^3$）がすべて PASS。$\pi_6^3$ の ProofStep 50件、Reference 8件、未解決 Goal 0、Web key `generic-complete-proof`、内部 DB 出典の不変を確認した。Phase 末尾の**現行アクティブ `tests/` 全体 pytest は1回のみ**実施し、`3546 passed in 107.52s (0:01:47)`、終了コード0。実行前後の追跡済みファイルの状態は一致した。

過去の「Phase 172 は候補・未実装」という記述は記録時点の履歴であり、本節が最新の正式状態である。次 Phase の内容はこの Phase 172 に含まれず、別途決定する。

<!-- PHASE173_R15R17_CHECKPOINT_20261104 -->

## Phase 173 R15R17 — 証明表示の単一 Model 統合と未完成状態の境界（2026-11-04、終了前）

Phase 173 は継続中であり、本節は R15R17 の HTTP 監査までの確認結果である。公開経路では、型付き Backward Search（逆向き探索）結果と別に Certified Abstract Structure（検証済み抽象群構造）が存在する場合、実際の検証済み ProofStep の祖先を **同一の `ProofNarrativeModel`** に取り込む。Reference（引用文献）を一か所に投影し、共通 Narrative Renderer（文章表示器）で一度だけ描画する。個別 $(n,k)$、生成元名または群名に対応した Narrative 分岐は追加しない。

検証済みの抽象群結論と記名生成元による群構造の完成証明は異なる。例えば $\pi_{12}^{4}\cong\mathbb Z/2$ の抽象群構造が導けても、$\varepsilon_4$ を生成元とする構造表示まで完成したとはみなさない。`PartialProofResult` の `status`、`conclusion`、`open_goals`、`diagnostics` は変更しない。`model.steps` には検証済みの抽象群祖先を表示用に追加するが、探索の `proven_steps` は不変とする。

内部の `CyclicStructureStatement`、順向きの `Relation`、逆向きの `Relation` は異なる Goal（未解決目標）として保持する。型付き群構造の一致を確認できる場合だけ公開表示を集約する。文字列の等値だけを証明上の等値とみなさない。参照先を持つ GIVEN（与件）で数式表示不能な内部型は本文へ生の Python 型名として出さず、その ProofStep と Citation の対応を維持する。

R3R4 は旧来の別 Section を要求する**公開 Web テスト契約**を統一後の経路に整えた。独立した legacy（互換経路）や補助 API の契約を一律に廃止していない。R3R5 の Flask HTTP 検査では、$(n,k)=(4,8),(4,9),(5,3),(4,4)$ の4件が 200 を返し、Reference は各1か所、model-backed 経路の旧抽象群 sidecar（追記部）は不在、証明状態は内部の検証済み状態と一致した。

**未確認：** ブラウザでの数式・レイアウトの目視確認、Phase 173 末尾のアクティブ `tests/` 全体 pytest、Phase 173 正式終了。旧 Phase の記録を改変しない。本節は新たな数学定理の証明や任意の群の証明完成を意味しない。

<!-- PHASE173_FINAL_CLOSEOUT_20261105 -->

## Phase 173 正式終了 — 共通 Narrative の最終設計境界（2026-11-05）

**公開経路の責務：** Backward Search（逆向き証明探索）→ Verified Proof Tree（検証済み証明木）→ 単一の `ProofNarrativeModel`（証明文章モデル）→ 共通 Narrative Renderer（文章表示器）→ Flask Web とする。検証済み抽象群構造の祖先 ProofStep は同一 Model に統合し、Reference（根拠一覧）を一度だけ描画する。群の次元や生成元の名称による新しい Narrative 分岐は設けない。

**不変条件：** 証明木中の引用、`ProofSearchStatus`、`open_goals`、`diagnostics` を表示側で生成・変更しない。型付きの等価な未解決 Goal は表示上まとめても、内部ではすべて保持する。$\pi_{12}^{4}\cong\mathbb Z/2$ と $\pi_{12}^{4}=\mathbb Z/2\{\varepsilon_4\}$ は、前者の抽象群構造だけが検証済みである。$\pi_{13}^{4}\cong(\mathbb Z/2)^3$ と記名直和生成元の証明も同様に区別する。$\pi_8^5$ は未完成、$\pi_8^4$ は完成を維持した。

**テスト結果と境界：** R15R17 R3R5 の Flask HTTP 4例、ブラウザからの文字列確認4例、旧 Phase 167 Reference テスト3ファイルの修正後限定 pytest 6 PASS。Phase 173 最終 Gate 初回は **3541 PASS／5 FAIL**（旧 `証明` 見出しを探す5 assertion）。修正後の R2 最終 Gate は Git HEAD `25b1ee1f7c848356604061991db06265cfccb296` で **3546 PASS（80.58秒、終了コード0）**、Source Guard と Git index 保持 PASS。旧失敗の機械生成原本4ファイルは現在の Windows プロファイルから参照できず、**原本保存状態は未検証**。ブラウザの MathJax 画素レベル検証も未確認である。

この終了認定は共通表示の経路・テスト契約と個別の検証済み結果に限定する。任意の群の記名生成元証明、登録された文献命題の全真偽、一般的な数学的探索の完成は主張しない。将来 Phase で必要な数学的 Goal を別途扱う。

<!-- PHASE174_R73_CLOSEOUT_PREPARATION_20261111 -->

## Phase 174 R73 — 共通証明経路と Closeout 前の設計境界（2026-11-11）

Phase 174 は **R73 時点では正式終了していない**。R71・R72 の限定 Gate は通過したが、Phase 末尾の現行アクティブ `tests/` 全体 pytest と最終 Git・文書整合確認は未実施である。R73 は全文文書を整備する工程であり、新しい数学的証明を追加する工程ではない。

### 現在有効な公開経路

```text
出典付きの型付き Goal
→ Source-first Backward Search（出典優先の逆向き探索）
→ Verified Proof Tree（検証済み証明木）
→ 単一 ProofNarrativeModel（証明文章モデル）
→ 共通 Narrative Renderer（文章表示器）
→ Web Group proof
```

探索は First Successful Proof Search（最初に成功した証明で終了）であり、唯一性検査を実施しない。`GIVEN`（文献・先行結果の採用）と `INFERENCE`（一般規則による導出）の責務を分ける。特定の群・生成元・次元専用の Narrative（文章分岐）や、結論を直接 GIVEN とする登録は導入しない。

### R70／R70R1 の表示限定性

`phase174_r3_r7_r70_verified_narrative_projection/projection.py` は、完成した証明木の根の祖先内にある型付き ProofStep と Citation の対応を要求し、合成像・結合法則・零像、Δ 全射性、EHP 完全性による説明を共通の表示へ投影する。R70R1 は associativity（結合法則）による一段の型付き証明連鎖をたどる条件を補正した。不一致・欠落・曖昧な場合には表示変換を実行しない fail-closed（検証不能なら変換しない）方式を維持する。

`E=0` と `H の単射性` の説明は、既に検証された四前提の零群一般推論規則の論理的帰結を文章にしたものであり、新たな独立 ProofStep として数えてはならない。`ProofSearchStatus`、`conclusion`、`open_goals`、`diagnostics`、証明木と引用数は Renderer が変更しない。

### 公開回帰の境界

R71 は完成8群の実探索と共通表示・引用数を監査し、限定 pytest 81 PASS。R72 はその保存レポートを確認し、未完成の $\pi_{12}^{4}$ と $\pi_{35}^{4}$ が `SEARCH_FAILED` のまま共通 Renderer／Web で表示されることを確認し、限定 pytest 38 PASS。R72 までの本番コード変更、新規 GIVEN、新規数学推論規則はいずれも 0 件。

これは登録されたすべての数学的文章の意味を個別に証明したという認定ではない。文献転記全件の正しさ、任意の $(n,k)$ の証明完成、ブラウザにおける全数式の画素単位の表示確認も未認定である。正式 Closeout は次の最終 Gate で判定する。

<!-- PHASE174_FINAL_CLOSEOUT_20261111 -->

## Phase 174 正式終了 — 現行設計の検証境界（2026-11-11）

Phase 174 の終了監査 R74 において、現行アクティブ `tests/` に対する全体 pytest を Phase 末尾に1回実行し、**3546 PASS**（`3546 passed in 40.86s`）を確認した。検証時の `develop` HEAD は `38788cec179c16fba7bba606ed35aa1e890ee79f`。標準出力の SHA-256 は `6681f47c76e282204ea4a590349a74041f568d1cce46ece9f5260619ec3aa5f8`。これは保存された R74 の実行証拠に基づく記録であり、未実施の全テストや出典の全面的な真偽を保証しない。

現行の公開証明経路は、Source-first（出典優先）の型付き Backward Search（後向き探索）→ Verified Proof Tree（検証済み証明木）→ 単一 `ProofNarrativeModel`（証明文章モデル）→ 共通 Renderer（表示器）→ Web である。First Successful Proof Search（最初の成功で終了）を維持し、唯一性検査は行わない。個々の $(n,k)$ や生成元に専用の数学的証明・Narrative（叙述）を加えない。

R70/R70R1 の一般的な表示変換は、合成・結合法則・零像について実際の型付き ProofStep（証明段階）の根祖先と引用を確認した場合にのみ文章を集約する。不確実な証拠では変換をしない。零群に至る $E=0$ と $H$ の単射性についての文章は、既存の4前提一般規則の説明であり、新たな独立 ProofStep ではない。

R71 は完成8群の公開状態と Reference（出典）を回帰検査した。R72 は $\pi_{12}^{4}$、$\pi_{35}^{4}$ の記名生成元 Goal（証明目標）が未完成のままであることを確認した。表示で未完成を完成扱いに変えない。今回の終了は、これらの特定の証明・実装・アクティブテストに限る。出典文献の全命題、任意の群、全文章の独立数学検証、ブラウザ画素品質は対象外とする。
